import React, { useState, useEffect, useRef } from "react";
import { Property, PropertyExpense, TenantContractRecord, getEffectivePropertyFinancials } from "../types";
import { validateAttachment, newAttachmentId, contractPdfSource, hasAttachmentSource } from "../lib/attachmentRules";
import { uploadAttachment, uploadBytesVerified, downloadAttachment, StoredAttachment } from "../lib/attachments";
import type { PendingAttachmentReference } from "../lib/attachmentPersistence";
import { externalizeImportedProperties } from "../lib/importAttachments";
import {
  IMPORT_ACCEPT,
  validateImportFileName,
  parsePropertiesFromText,
  parsePropertiesFromRows,
  ImportIssue,
} from "../lib/importParsers";
import * as XLSX from "xlsx";
import { 
  Building, 
  User, 
  Coins, 
  MapPin, 
  CreditCard, 
  Trash2, 
  Plus, 
  Edit3, 
  X, 
  Check, 
  Calculator,
  RefreshCw,
  Info,
  AlertCircle,
  FileText,
  Upload,
  Download,
  FileSpreadsheet,
  FileCode,
  Calendar,
  Sparkles,
  Loader2,
  CheckCircle,
  UserPlus,
  Users,
  History,
  UserCheck,
  ArrowRight
} from "lucide-react";

interface PropertiesProps {
  currentUser?: string;
  properties: Property[];
  onAddProperty: (newProperty: Property, attachments?: PendingAttachmentReference[]) => void | Promise<void>;
  onEditProperty: (updatedProperty: Property, attachments?: PendingAttachmentReference[]) => void | Promise<void>;
  onDeleteProperty: (id: string) => void;
  onDeleteExpense: (id: string) => void;
  onImportProperties?: (newProperties: Property[], mode: 'merge' | 'replace') => void;
  user1Name: string;
  user2Name: string;
  hasPartner: boolean;
  expenses?: PropertyExpense[];
  currentYear?: number;
}

export default function Properties({ 
  currentUser,
  properties, 
  onAddProperty, 
  onEditProperty, 
  onDeleteProperty,
  onDeleteExpense,
  onImportProperties,
  user1Name,
  user2Name,
  hasPartner,
  expenses = [],
  currentYear = 2026
}: PropertiesProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [openFiscalPropertyId, setOpenFiscalPropertyId] = useState<string | null>(null);
  const [fiscalFilterYear, setFiscalFilterYear] = useState<number>(currentYear);
  const [deleteExpenseConfirmId, setDeleteExpenseConfirmId] = useState<string | null>(null);

  // New states for real estate performance metrics and document manager
  const [openFinancialsPropertyId, setOpenFinancialsPropertyId] = useState<string | null>(null);
  const [openDocsPropertyId, setOpenDocsPropertyId] = useState<string | null>(null);

  // Import / Export states
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [importPreviewData, setImportPreviewData] = useState<Property[] | null>(null);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [importError, setImportError] = useState<string | null>(null);
  const [importSuccessMsg, setImportSuccessMsg] = useState<string | null>(null);
  const [importRejected, setImportRejected] = useState<ImportIssue[]>([]);
  const [importWarnings, setImportWarnings] = useState<ImportIssue[]>([]);
  const [importStructureNote, setImportStructureNote] = useState<string | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [financialYear, setFinancialYear] = useState<number>(currentYear);
  const [docYear, setDocYear] = useState<number>(currentYear);

  const [finCurrentValue, setFinCurrentValue] = useState("");
  const [finPurchasePrice, setFinPurchasePrice] = useState("");
  const [finPurchaseExpenses, setFinPurchaseExpenses] = useState("");
  const [finMortgageDebt, setFinMortgageDebt] = useState("");
  const [finMonthlyMortgagePayment, setFinMonthlyMortgagePayment] = useState("");
  const [finInterestRate, setFinInterestRate] = useState("");
  const [finStartDate, setFinStartDate] = useState("");
  const [finTermYears, setFinTermYears] = useState("");
  const [isMortgageCalculatedState, setIsMortgageCalculatedState] = useState(false);

  const [docCategory, setDocCategory] = useState<'ibi' | 'seguros' | 'comunidad' | 'reparaciones' | 'muebles_electrodomesticos' | 'otros'>('ibi');
  const [pendingDocFile, setPendingDocFile] = useState<File | null>(null);
  const [docError, setDocError] = useState<string | null>(null);
  const [docIsSaving, setDocIsSaving] = useState(false);
  const docSavingRef = useRef(false);
  const docDraftIdRef = useRef<string | null>(null);
  const uploadedDocRef = useRef<{ file: File; propertyId: string; stored: StoredAttachment } | null>(null);
  const uploadedContractRef = useRef<{ file: File; propertyId: string; stored: StoredAttachment } | null>(null);
  const cardSavingRef = useRef(false);
  const cardTenantIdRef = useRef<string | null>(null);
  const [uploadedFileName, setUploadedFileName] = useState("");
  const [uploadedFileSize, setUploadedFileSize] = useState("");
  const [uploadedFileType, setUploadedFileType] = useState("");
  const [docUploadSuccess, setDocUploadSuccess] = useState(false);
  const [docIsUploading, setDocIsUploading] = useState(false);

  useEffect(() => {
    setFiscalFilterYear(currentYear);
    setFinancialYear(currentYear);
    setDocYear(currentYear);
  }, [currentYear]);

  // Sync financial form fields when selecting a property or changing years
  useEffect(() => {
    if (openFinancialsPropertyId) {
      const prop = properties.find(p => p.id === openFinancialsPropertyId);
      if (prop) {
        const eff = getEffectivePropertyFinancials(prop, financialYear);
        setFinCurrentValue(eff.currentValue.toString());
        setFinPurchasePrice(eff.purchasePrice.toString());
        setFinPurchaseExpenses(eff.purchaseExpenses.toString());
        setFinMortgageDebt(eff.mortgageDebt.toString());
        setFinMonthlyMortgagePayment(eff.monthlyMortgagePayment.toString());
        setFinInterestRate(prop.mortgageInterestRate?.toString() ?? "");
        setFinStartDate(prop.mortgageStartDate ?? "");
        setFinTermYears(prop.mortgageTermYears?.toString() ?? "");
        setIsMortgageCalculatedState(eff.isMortgageCalculated ?? false);
      }
    }
  }, [openFinancialsPropertyId, financialYear, properties]);

  const handleSaveFinancials = (prop: Property) => {
    const updatedYearly = {
      ...(prop.yearlyFinancials || {})
    };

    const numCurrentValue = Number(finCurrentValue.toString().replace(",", ".") || 0);
    const numPurchasePrice = Number(finPurchasePrice.toString().replace(",", ".") || 0);
    const numPurchaseExpenses = Number(finPurchaseExpenses.toString().replace(",", ".") || 0);
    const numMortgageDebt = Number(finMortgageDebt.toString().replace(",", ".") || 0);
    const numMonthlyMortgagePayment = Number(finMonthlyMortgagePayment.toString().replace(",", ".") || 0);
    const numInterestRate = Number(finInterestRate.toString().replace(",", ".") || 0);
    const numTermYears = Number(finTermYears.toString().replace(",", ".") || 0);

    updatedYearly[financialYear] = {
      currentValue: numCurrentValue,
      purchasePrice: numPurchasePrice,
      purchaseExpenses: numPurchaseExpenses,
      mortgageDebt: numMortgageDebt,
      monthlyMortgagePayment: numMonthlyMortgagePayment,
      isManual: true,
    };

    const updatedProp: Property = {
      ...prop,
      purchasePrice: numPurchasePrice || prop.purchasePrice || 0,
      currentValue: numCurrentValue,
      mortgageDebt: numMortgageDebt,
      monthlyMortgagePayment: numMonthlyMortgagePayment,
      mortgageInterestRate: numInterestRate,
      mortgageStartDate: finStartDate || undefined,
      mortgageTermYears: numTermYears,
      yearlyFinancials: updatedYearly
    };
    
    onEditProperty(updatedProp);
  };

  const handleUploadDocLocal = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const invalid = validateAttachment(file);
    if (docSavingRef.current) return;
    if (invalid) {
      setDocError(invalid);
      setDocUploadSuccess(false);
      return;
    }
    // Solo se selecciona aquí; la subida real a Storage ocurre al pulsar "Integrar Documento".
    docDraftIdRef.current = newAttachmentId("doc");
    uploadedDocRef.current = null;
    setDocError(null);
    setPendingDocFile(file);
    setUploadedFileName(file.name);
    setUploadedFileSize(`${(file.size / (1024 * 1024)).toFixed(2)} MB`);
    setUploadedFileType(file.type || "application/pdf");
    setDocUploadSuccess(true);
  };


  const handleSaveDocument = async (prop: Property): Promise<boolean> => {
    if (!pendingDocFile || docSavingRef.current) return false;
    if (!currentUser) { setDocError("No hay una sesión activa para subir el documento."); return false; }
    docSavingRef.current = true;
    setDocIsSaving(true);
    setDocError(null);
    const documentId = docDraftIdRef.current ??= newAttachmentId("doc");
    try {
      const cached = uploadedDocRef.current;
      const stored = cached?.file === pendingDocFile && cached.propertyId === prop.id ? cached.stored : await uploadAttachment({
        userId: currentUser, folder: "property-documents", file: pendingDocFile, propertyId: prop.id,
      });
      uploadedDocRef.current = { file: pendingDocFile, propertyId: prop.id, stored };
      const newDoc = {
        id: documentId, name: stored.name, size: uploadedFileSize, type: stored.contentType,
        category: docCategory, year: docYear, uploadDate: new Date().toLocaleDateString('es-ES'),
        storagePath: stored.mode === "storage" ? stored.storagePath : undefined,
        vaultId: stored.mode === "vault" ? stored.vaultId : undefined, contentType: stored.contentType,
      };
      const updatedProp: Property = {
        ...prop, documents: [...(prop.documents || []).filter((d) => d.id !== documentId), newDoc],
      };
      await onEditProperty(updatedProp, [{ storagePath: stored.storagePath, vaultId: stored.vaultId, propertyId: prop.id }]);
      setPendingDocFile(null); setUploadedFileName(""); setUploadedFileSize(""); setUploadedFileType(""); setDocUploadSuccess(false);
      uploadedDocRef.current = null; docDraftIdRef.current = null;
      return true;
    } catch (err) {
      setDocError(err instanceof Error ? err.message : "No se pudo confirmar el documento. El archivo y los datos se conservan.");
      return false;
    } finally { docSavingRef.current = false; setDocIsSaving(false); }
  };

  const handleDeleteDocument = (prop: Property, docId: string) => {
    const updatedProp: Property = {
      ...prop,
      documents: (prop.documents || []).filter(d => d.id !== docId)
    };
    onEditProperty(updatedProp);
  };

  const [openContractPropertyId, setOpenContractPropertyId] = useState<string | null>(null);

  // Card-level Contract Form State
  const [cardStartDate, setCardStartDate] = useState("");
  const [cardEndDate, setCardEndDate] = useState("");
  const [cardMonthlyRent, setCardMonthlyRent] = useState("");
  const [cardPdfName, setCardPdfName] = useState("");
  const [cardPdfFile, setCardPdfFile] = useState<File | null>(null);
  const [cardPdfPath, setCardPdfPath] = useState("");
  const [cardError, setCardError] = useState<string | null>(null);
  const [cardIsSaving, setCardIsSaving] = useState(false);
  const [cardPdfSize, setCardPdfSize] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  // New Tenant Registration state during contract change
  const [isTenantChangeActive, setIsTenantChangeActive] = useState(false);
  const [newTenantName, setNewTenantName] = useState("");
  const [newTenantDni, setNewTenantDni] = useState("");
  const [newTenantStartDate, setNewTenantStartDate] = useState("");
  const [newTenantMonthlyRent, setNewTenantMonthlyRent] = useState("");
  const [newTenantPdfName, setNewTenantPdfName] = useState("");
  const [newTenantPdfSize, setNewTenantPdfSize] = useState("");

  const handleToggleContractPanel = (prop: Property) => {
    if (cardSavingRef.current) return;
    if (openContractPropertyId === prop.id) {
      setOpenContractPropertyId(null);
    } else {
      setOpenContractPropertyId(prop.id);
      setOpenFiscalPropertyId(null);
      // Reset states
      setIsTenantChangeActive(false);
      setNewTenantName("");
      setNewTenantDni("");
      setNewTenantStartDate("");
      setNewTenantMonthlyRent("");
      setNewTenantPdfName("");
      setNewTenantPdfSize("");

      setCardStartDate(prop.contract?.startDate || "");
      setCardEndDate(prop.contract?.endDate || "");
      setCardMonthlyRent(prop.contract?.monthlyRent?.toString() || prop.monthlyRent?.toString() || "0");
      setCardPdfName(prop.contract?.pdfName || "");
      setCardPdfPath(prop.contract?.pdfPath || "");
      setCardPdfFile(null);
      setCardError(null);
      setCardPdfSize(prop.contract?.pdfSize || "");
      setUploadSuccess(!!prop.contract?.pdfName);
      setIsUploading(false);
    }
  };

  const handleSaveCardContract = async (prop: Property): Promise<boolean> => {
    if (cardSavingRef.current) return false;
    cardSavingRef.current = true;
    setCardIsSaving(true);
    setCardError(null);
    let newPdfPath: string | undefined;
    let newPdfVaultId: string | undefined;
    if (cardPdfFile) {
      if (!currentUser) {
        setCardError("No hay una sesión activa para subir el contrato.");
        cardSavingRef.current = false; setCardIsSaving(false);
        return false;
      }
      setCardIsSaving(true);
      setCardError(null);
      try {
        const cached = uploadedContractRef.current;
        const storedContract = cached?.file === cardPdfFile && cached.propertyId === prop.id ? cached.stored : await uploadAttachment({
          userId: currentUser,
          folder: "contracts",
          file: cardPdfFile,
          propertyId: prop.id,
        });
        uploadedContractRef.current = { file: cardPdfFile, propertyId: prop.id, stored: storedContract };
        newPdfPath = storedContract.storagePath;
        newPdfVaultId = storedContract.vaultId;
      } catch (err) {
        setCardIsSaving(false);
        setCardError(err instanceof Error ? err.message : "No se pudo subir el contrato.");
        cardSavingRef.current = false;
        return false;
      }
    }
    // Archivo nuevo => solo su proveedor; nunca conservar una referencia antigua prioritaria.
    const effectivePdfPath = cardPdfFile ? newPdfPath : (cardPdfName ? cardPdfPath || undefined : undefined);
    const effectivePdfVaultId = cardPdfFile ? newPdfVaultId : (cardPdfName ? prop.contract?.pdfVaultId : undefined);
    let updatedHistory: TenantContractRecord[] = prop.tenantHistory && prop.tenantHistory.length > 0
      ? [...prop.tenantHistory]
      : [];

    // If history is empty, initialize record for outgoing/current tenant
    if (updatedHistory.length === 0 && prop.tenantName) {
      updatedHistory.push({
        id: `rec_init_${prop.id}`,
        tenantName: prop.tenantName,
        tenantDni: prop.tenantDni || "",
        startDate: cardStartDate || prop.contract?.startDate || "2024-01-01",
        endDate: cardEndDate || prop.contract?.endDate || undefined,
        monthlyRent: Number(cardMonthlyRent.toString().replace(",", ".") || prop.monthlyRent || 0),
        pdfName: cardPdfName || prop.contract?.pdfName,
        pdfSize: cardPdfSize || prop.contract?.pdfSize,
        pdfPath: cardPdfFile ? effectivePdfPath : effectivePdfPath || prop.contract?.pdfPath,
        pdfVaultId: cardPdfFile ? effectivePdfVaultId : effectivePdfVaultId || prop.contract?.pdfVaultId
      });
    } else if (updatedHistory.length > 0) {
      // Update the latest existing record with the entered contract details
      const lastIdx = updatedHistory.length - 1;
      updatedHistory[lastIdx] = {
        ...updatedHistory[lastIdx],
        startDate: cardStartDate || updatedHistory[lastIdx].startDate,
        endDate: cardEndDate || updatedHistory[lastIdx].endDate,
        monthlyRent: Number(cardMonthlyRent.toString().replace(",", ".") || updatedHistory[lastIdx].monthlyRent || 0),
        pdfName: cardPdfName || updatedHistory[lastIdx].pdfName,
        pdfSize: cardPdfSize || updatedHistory[lastIdx].pdfSize,
        pdfPath: cardPdfFile ? effectivePdfPath : effectivePdfPath || updatedHistory[lastIdx].pdfPath,
        pdfVaultId: cardPdfFile ? effectivePdfVaultId : effectivePdfVaultId || updatedHistory[lastIdx].pdfVaultId
      };
    }

    let activeTenantName = prop.tenantName;
    let activeTenantDni = prop.tenantDni;
    let activeMonthlyRent = Number(cardMonthlyRent.toString().replace(",", ".") || prop.monthlyRent || 0);
    let activeContract = {
      startDate: cardStartDate || new Date().toISOString().split('T')[0],
      endDate: cardEndDate || undefined,
      monthlyRent: activeMonthlyRent,
      pdfName: cardPdfName || undefined,
      pdfSize: cardPdfSize || undefined,
      pdfPath: effectivePdfPath,
      pdfVaultId: effectivePdfVaultId
    };

    // If tenant change is requested and a new tenant name is provided
    if (isTenantChangeActive && newTenantName.trim()) {
      const newRentNum = Number(newTenantMonthlyRent.toString().replace(",", ".") || activeMonthlyRent);
      const newStartStr = newTenantStartDate || cardEndDate || new Date().toISOString().split("T")[0];

      // Ensure last tenant record has end date specified
      if (updatedHistory.length > 0) {
        const lastIdx = updatedHistory.length - 1;
        if (!updatedHistory[lastIdx].endDate && cardEndDate) {
          updatedHistory[lastIdx].endDate = cardEndDate;
        } else if (!updatedHistory[lastIdx].endDate) {
          const d = new Date(newStartStr);
          d.setDate(d.getDate() - 1);
          updatedHistory[lastIdx].endDate = d.toISOString().split("T")[0];
        }
      }

      const newRecord: TenantContractRecord = {
        id: cardPdfFile ? (cardTenantIdRef.current ??= newAttachmentId("rec_tenant")) : `rec_tenant_${Date.now()}`,
        tenantName: newTenantName.trim(),
        tenantDni: newTenantDni.trim(),
        startDate: newStartStr,
        endDate: undefined,
        monthlyRent: newRentNum,
        pdfName: newTenantPdfName || undefined,
        pdfSize: newTenantPdfSize || undefined
      };

      updatedHistory = updatedHistory.filter((r) => r.id !== newRecord.id);
      updatedHistory.push(newRecord);

      activeTenantName = newTenantName.trim();
      activeTenantDni = newTenantDni.trim();
      activeMonthlyRent = newRentNum;
      activeContract = {
        startDate: newStartStr,
        endDate: undefined,
        monthlyRent: newRentNum,
        pdfName: newTenantPdfName || undefined,
        pdfSize: newTenantPdfSize || undefined,
        pdfPath: undefined,
        pdfVaultId: undefined
      };
    }

    const updatedProp: Property = {
      ...prop,
      tenantName: activeTenantName,
      tenantDni: activeTenantDni,
      monthlyRent: activeMonthlyRent,
      contract: activeContract,
      tenantHistory: updatedHistory
    };

    try {
      await onEditProperty(updatedProp, cardPdfFile ? [{ storagePath: newPdfPath, vaultId: newPdfVaultId, propertyId: prop.id }] : undefined);
    } catch (err) {
      setCardError(err instanceof Error ? err.message : "No se pudo confirmar el contrato. Los datos se conservan.");
      return false;
    } finally { cardSavingRef.current = false; setCardIsSaving(false); }

    // Reset transition fields
    setIsTenantChangeActive(false);
    setNewTenantName("");
    setNewTenantDni("");
    setNewTenantStartDate("");
    setNewTenantMonthlyRent("");
    setNewTenantPdfName("");
    setNewTenantPdfSize("");
    uploadedContractRef.current = null;
    cardTenantIdRef.current = null;
    return true;
  };

  const handleDeleteCardContract = (prop: Property) => {
    handleDeleteTenantRecord(prop);
  };

  const handleDeleteTenantRecord = (prop: Property, recordId?: string, recordIndex?: number) => {
    const history: TenantContractRecord[] = prop.tenantHistory && prop.tenantHistory.length > 0
      ? [...prop.tenantHistory]
      : (prop.tenantName ? [{
          id: `rec_${prop.id}`,
          tenantName: prop.tenantName,
          tenantDni: prop.tenantDni || "",
          startDate: prop.contract?.startDate || "2024-01-01",
          endDate: prop.contract?.endDate,
          monthlyRent: prop.contract?.monthlyRent || prop.monthlyRent || 0,
          pdfName: prop.contract?.pdfName,
          pdfSize: prop.contract?.pdfSize
        }] : []);

    let updatedHistory: TenantContractRecord[] = [];

    if (recordId) {
      updatedHistory = history.filter((r, idx) => r.id !== recordId && (recordIndex === undefined || idx !== recordIndex));
    } else if (recordIndex !== undefined && recordIndex >= 0) {
      updatedHistory = history.filter((_, idx) => idx !== recordIndex);
    } else {
      updatedHistory = history.slice(0, -1);
    }

    let updatedProp: Property;

    if (updatedHistory.length === 0) {
      updatedProp = {
        ...prop,
        tenantName: "",
        tenantDni: "",
        contract: undefined,
        tenantHistory: []
      };
      setCardStartDate("");
      setCardEndDate("");
      setCardMonthlyRent(prop.monthlyRent ? prop.monthlyRent.toString() : "0");
      setCardPdfName("");
      setCardPdfSize("");
      setCardPdfPath("");
      setCardPdfFile(null);
    } else {
      const lastActive = updatedHistory[updatedHistory.length - 1];
      const todayIso = new Date().toISOString().split("T")[0];
      
      // If the restored last active tenant had a past end date assigned due to the contract change that was just deleted, reactivate it
      let activeEndDate = lastActive.endDate;
      if (activeEndDate && activeEndDate < todayIso) {
        activeEndDate = undefined;
        updatedHistory[updatedHistory.length - 1] = {
          ...lastActive,
          endDate: undefined
        };
      }

      updatedProp = {
        ...prop,
        tenantName: lastActive.tenantName,
        tenantDni: lastActive.tenantDni,
        monthlyRent: lastActive.monthlyRent,
        contract: {
          startDate: lastActive.startDate,
          endDate: activeEndDate,
          monthlyRent: lastActive.monthlyRent,
          pdfName: lastActive.pdfName,
          pdfSize: lastActive.pdfSize
        },
        tenantHistory: updatedHistory
      };
      setCardStartDate(lastActive.startDate || "");
      setCardEndDate(activeEndDate || "");
      setCardMonthlyRent(lastActive.monthlyRent ? lastActive.monthlyRent.toString() : "0");
      setCardPdfName(lastActive.pdfName || "");
      setCardPdfPath(lastActive.pdfPath || "");
      setCardPdfFile(null);
      setCardPdfSize(lastActive.pdfSize || "");
    }

    onEditProperty(updatedProp);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, prop: Property) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const invalid = validateAttachment(file);
    if (invalid) {
      setCardError(invalid);
      return;
    }
    // Solo se selecciona; el PDF se sube a Storage al pulsar "Guardar Contrato".
    setCardError(null);
    setCardPdfFile(file);
    setCardPdfPath("");
    setUploadSuccess(true);
    setCardPdfName(file.name);
    setCardPdfSize(`${(file.size / (1024 * 1024)).toFixed(2)} MB`);

    if (!cardStartDate) {
      setCardStartDate("2026-01-01");
    }
    if (!cardMonthlyRent || cardMonthlyRent === "0") {
      setCardMonthlyRent(prop.monthlyRent.toString() || "1200");
    }
    if (!cardEndDate) {
      setCardEndDate("2027-01-01");
    }
  };

  // Form State
  const [address, setAddress] = useState("");
  const [cadastralReference, setCadastralReference] = useState("");
  const [owner, setOwner] = useState<'user1' | 'user2' | 'both'>('user1');
  const [pctU1, setPctU1] = useState("100");
  const [pctU2, setPctU2] = useState("0");
  const [tenantName, setTenantName] = useState("");
  const [tenantDni, setTenantDni] = useState("");
  const [monthlyRent, setMonthlyRent] = useState("0");
  const [purchasePrice, setPurchasePrice] = useState("0");
  const [landValuePercent, setLandValuePercent] = useState("25");
  const [expensesCommunity, setExpensesCommunity] = useState("0");
  const [expensesIBI, setExpensesIBI] = useState("0");
  const [expensesInsurance, setExpensesInsurance] = useState("0");
  const [expensesRepairs, setExpensesRepairs] = useState("0");

  const [contractStartDate, setContractStartDate] = useState("");
  const [contractEndDate, setContractEndDate] = useState("");
  const [contractMonthlyRent, setContractMonthlyRent] = useState("");
  const [contractPdfName, setContractPdfName] = useState("");
  const [contractPdfFile, setContractPdfFile] = useState<File | null>(null);
  const [contractPdfPath, setContractPdfPath] = useState("");
  const [contractPdfError, setContractPdfError] = useState<string | null>(null);
  const [isSavingProperty, setIsSavingProperty] = useState(false);
  const savingPropertyRef = useRef(false);
  const draftPropertyIdRef = useRef<string | null>(null);
  const [contractPdfSize, setContractPdfSize] = useState("");

  const resetForm = () => {
    draftPropertyIdRef.current = null;
    uploadedContractRef.current = null;
    setAddress("");
    setCadastralReference("");
    setOwner('user1');
    setPctU1("100");
    setPctU2("0");
    setTenantName("");
    setTenantDni("");
    setMonthlyRent("0");
    setPurchasePrice("0");
    setLandValuePercent("25");
    setExpensesCommunity("0");
    setExpensesIBI("0");
    setExpensesInsurance("0");
    setExpensesRepairs("0");
    setContractStartDate("");
    setContractEndDate("");
    setContractMonthlyRent("");
    setContractPdfName("");
    setContractPdfSize("");
    setContractPdfFile(null);
    setContractPdfPath("");
    setContractPdfError(null);
  };

  const handleStartEdit = (prop: Property) => {
    setEditingId(prop.id);
    setAddress(prop.address);
    setCadastralReference(prop.cadastralReference);
    setOwner(prop.owner);
    setPctU1(prop.ownershipPercentageUser1.toString());
    setPctU2(prop.ownershipPercentageUser2.toString());
    setTenantName(prop.tenantName);
    setTenantDni(prop.tenantDni);
    setMonthlyRent(prop.monthlyRent.toString());
    setPurchasePrice(prop.purchasePrice.toString());
    setLandValuePercent(prop.landValuePercent.toString());
    setExpensesCommunity(prop.expensesCommunity.toString());
    setExpensesIBI(prop.expensesIBI.toString());
    setExpensesInsurance(prop.expensesInsurance.toString());
    setExpensesRepairs(prop.expensesRepairs.toString());
    setContractStartDate(prop.contract?.startDate || "");
    setContractEndDate(prop.contract?.endDate || "");
    setContractMonthlyRent(prop.contract?.monthlyRent?.toString() || "");
    setContractPdfName(prop.contract?.pdfName || "");
    setContractPdfPath(prop.contract?.pdfPath || "");
    setContractPdfFile(null);
    setContractPdfError(null);
    setContractPdfSize(prop.contract?.pdfSize || "");
  };

  const handleOwnerChange = (val: 'user1' | 'user2' | 'both') => {
    setOwner(val);
    if (val === 'user1') {
      setPctU1("100");
      setPctU2("0");
    } else if (val === 'user2') {
      setPctU1("0");
      setPctU2("100");
    } else {
      setPctU1("50");
      setPctU2("50");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!address.trim() || savingPropertyRef.current) return;
    const propertyId = editingId || (draftPropertyIdRef.current ??= newAttachmentId("prop"));
    const existingProp = editingId ? properties.find(p => p.id === editingId) : undefined;
    savingPropertyRef.current = true;
    setIsSavingProperty(true);
    setContractPdfError(null);
    try {

    // Calculate Amortization amount based on Spanish law: 3% on construction value (acquisition cost minus land value)
    const safePrice = Number(purchasePrice.toString().replace(",", ".") || 0);
    const safeLand = Number(landValuePercent.toString().replace(",", ".") || 0);
    const constructionValue = safePrice * (100 - safeLand) / 100;
    const computedAmortization = Number((constructionValue * 0.03).toFixed(2));

    // Si se ha elegido un PDF nuevo, se sube antes de guardar el inmueble. Si falla, no se guarda nada.
    let newContractPdfPath: string | undefined;
    let newContractPdfVaultId: string | undefined;
    if (contractPdfFile) {
      if (!currentUser) throw new Error("No hay una sesión activa para subir el contrato.");
      const cached = uploadedContractRef.current;
      const storedPropContract = cached?.file === contractPdfFile && cached.propertyId === propertyId ? cached.stored : await uploadAttachment({
        userId: currentUser, folder: "contracts", file: contractPdfFile, propertyId,
      });
      uploadedContractRef.current = { file: contractPdfFile, propertyId, stored: storedPropContract };
      newContractPdfPath = storedPropContract.storagePath;
      newContractPdfVaultId = storedPropContract.vaultId;
    }

    const hasContractData = contractStartDate || contractEndDate || contractMonthlyRent || contractPdfName;
    let finalContract = undefined;
    if (hasContractData) {
      finalContract = {
        startDate: contractStartDate || new Date().toISOString().split("T")[0],
        endDate: contractEndDate || undefined,
        monthlyRent: Number(contractMonthlyRent.toString().replace(",", ".") || monthlyRent.toString().replace(",", ".") || 0),
        pdfName: contractPdfName || undefined,
        pdfSize: contractPdfSize || undefined,
        pdfPath: contractPdfFile ? newContractPdfPath : contractPdfPath || undefined,
        pdfVaultId: contractPdfFile ? newContractPdfVaultId : existingProp?.contract?.pdfVaultId,
      };
    }
    if (existingProp?.contract && !hasContractData) {
      finalContract = existingProp.contract;
    }

    let defaultYearlyFinancials = undefined;
    if (!editingId) {
      // For a new property, generate standard 2025-2028 financials
      const defaultExpenses = Math.round(safePrice * 0.1); // 10% standard purchase expenses
      const defaultMortgageDebt = 0; // Default to no mortgage, can be set in financials
      const defaultMonthlyMortgagePayment = 0;
      
      const years = [2025, 2026, 2027, 2028];
      const yearlyRecord: Record<number, any> = {};
      years.forEach((yr) => {
        const yearsDiff = Math.max(0, yr - 2025);
        const estimatedCurrentValue = Math.round(safePrice * Math.pow(1.035, yearsDiff));
        yearlyRecord[yr] = {
          currentValue: estimatedCurrentValue,
          purchasePrice: safePrice,
          purchaseExpenses: defaultExpenses,
          mortgageDebt: defaultMortgageDebt,
          monthlyMortgagePayment: defaultMonthlyMortgagePayment
        };
      });
      defaultYearlyFinancials = yearlyRecord;
    }

    const propData: Property = {
      id: propertyId,
      address,
      cadastralReference,
      owner,
      ownershipPercentageUser1: Number(pctU1.toString().replace(",", ".") || 0),
      ownershipPercentageUser2: hasPartner ? Number(pctU2.toString().replace(",", ".") || 0) : 0,
      tenantName,
      tenantDni,
      monthlyRent: Number(monthlyRent.toString().replace(",", ".") || 0),
      purchasePrice: Number(purchasePrice.toString().replace(",", ".") || 0),
      landValuePercent: Number(landValuePercent.toString().replace(",", ".") || 0),
      amortizationAmount: computedAmortization,
      expensesCommunity: Number(expensesCommunity.toString().replace(",", ".") || 0),
      expensesIBI: Number(expensesIBI.toString().replace(",", ".") || 0),
      expensesInsurance: Number(expensesInsurance.toString().replace(",", ".") || 0),
      expensesRepairs: Number(expensesRepairs.toString().replace(",", ".") || 0),
      registrationDate: existingProp?.registrationDate || new Date().toLocaleDateString('es-ES'),
      contract: finalContract,
      yearlyFinancials: existingProp?.yearlyFinancials || defaultYearlyFinancials,
      documents: existingProp?.documents
    };

    if (editingId) {
      await onEditProperty(propData, contractPdfFile ? [{ storagePath: newContractPdfPath, vaultId: newContractPdfVaultId, propertyId }] : undefined);
      setEditingId(null);
    } else {
      await onAddProperty(propData, contractPdfFile ? [{ storagePath: newContractPdfPath, vaultId: newContractPdfVaultId, propertyId }] : undefined);
      setIsAdding(false);
    }
    resetForm();
    } catch (err) {
      setContractPdfError(err instanceof Error ? err.message : "No se pudo confirmar el contrato. Los datos se conservan para reintentar.");
    } finally { savingPropertyRef.current = false; setIsSavingProperty(false); }
  };

  // Property Export handlers
  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(properties, null, 2));
    const dlAnchor = document.createElement("a");
    dlAnchor.setAttribute("href", dataStr);
    dlAnchor.setAttribute("download", `inmuebles_rentasync_${new Date().toISOString().split("T")[0]}.json`);
    document.body.appendChild(dlAnchor);
    dlAnchor.click();
    dlAnchor.remove();
    setIsExportOpen(false);
  };

  const handleExportExcel = () => {
    const rows = properties.map((p) => ({
      "ID Inmueble": p.id,
      "Dirección Completa": p.address,
      "Referencia Catastral": p.cadastralReference || "",
      "Titularidad": p.owner,
      "% Propietario 1": p.ownershipPercentageUser1,
      "% Propietario 2": p.ownershipPercentageUser2,
      "Inquilino": p.tenantName || "",
      "DNI Inquilino": p.tenantDni || "",
      "Renta Mensual (€)": p.monthlyRent || 0,
      "Precio Adquisición (€)": p.purchasePrice || 0,
      "% Suelo Catastral": p.landValuePercent || 0,
      "Amortización Anual (€)": p.amortizationAmount || 0,
      "Gastos Comunidad (€)": p.expensesCommunity || 0,
      "Gastos IBI (€)": p.expensesIBI || 0,
      "Gastos Seguro (€)": p.expensesInsurance || 0,
      "Gastos Reparaciones (€)": p.expensesRepairs || 0,
      "Fecha Registro": p.registrationDate || ""
    }));

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Inmuebles");
    XLSX.writeFile(workbook, `inmuebles_${new Date().toISOString().split("T")[0]}.xlsx`);
    setIsExportOpen(false);
  };

  // Property Import handler
  const handleProcessImportFile = (file: File) => {
    setImportError(null);
    setImportSuccessMsg(null);
    setImportPreviewData(null);
    setImportRejected([]);
    setImportWarnings([]);
    setImportStructureNote(null);

    // La validación del formato se hace SIEMPRE tras la selección del archivo
    // (el filtro del selector del sistema no es fiable en Android), con un
    // mensaje claro si el formato no está admitido.
    const formatError = validateImportFileName(file.name);
    if (formatError) {
      setImportError(formatError);
      return;
    }

    const isJson = file.name.toLowerCase().endsWith(".json");
    const reader = new FileReader();

    const applyResult = (result: ReturnType<typeof parsePropertiesFromText>) => {
      setImportRejected(result.rejected);
      setImportWarnings(result.warnings);
      setImportStructureNote(
        result.structure.kind === "portfolio-backup"
          ? "Copia de seguridad integral de la cartera detectada: se importarán solo los inmuebles del respaldo. El archivo original no se modifica."
          : null
      );
      if (result.error) {
        setImportError(result.error);
        setImportPreviewData(null);
        return;
      }
      if (result.properties.length === 0) {
        setImportError(
          result.rejected.length > 0
            ? `Ningún inmueble se puede importar con seguridad: ${result.rejected.length} registro(s) con datos insuficientes (ver detalle). El archivo original no se modifica.`
            : "No se han encontrado inmuebles con datos válidos en el archivo."
        );
        setImportPreviewData(null);
        return;
      }
      setImportPreviewData(result.properties);
    };

    if (isJson) {
      reader.onload = (e) => applyResult(parsePropertiesFromText(String(e.target?.result ?? "")));
      reader.onerror = () => setImportError("No se ha podido leer el archivo seleccionado.");
      reader.readAsText(file);
    } else {
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const sheetName = workbook.SheetNames[0];
          const rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
          applyResult(parsePropertiesFromRows(rows));
        } catch (err) {
          setImportError("Error al procesar la hoja de cálculo. Comprueba que sea un archivo Excel (.xlsx, .xls) o CSV válido.");
          setImportPreviewData(null);
        }
      };
      reader.onerror = () => setImportError("No se ha podido leer el archivo seleccionado.");
      reader.readAsArrayBuffer(file);
    }
  };

  const handleConfirmImport = async () => {
    if (!importPreviewData || importPreviewData.length === 0 || isImporting) return;
    // Los documentos Base64 de la importación se suben a Storage ANTES de tocar la cartera.
    let prepared: Property[];
    setIsImporting(true);
    setImportError(null);
    try {
      if (!currentUser) throw new Error("No hay una sesión activa para importar los documentos.");
      prepared = await externalizeImportedProperties(importPreviewData, (req) =>
        uploadBytesVerified({ userId: currentUser, ...req })
      );
    } catch (err) {
      setIsImporting(false);
      setImportError(err instanceof Error ? err.message : "No se han podido guardar los documentos. La importación se ha cancelado.");
      return;
    }
    setIsImporting(false);
    if (onImportProperties) {
      onImportProperties(prepared, importMode);
      setImportSuccessMsg(`Se han importado con éxito ${prepared.length} inmuebles.`);
      setTimeout(() => {
        setIsImportOpen(false);
        setImportPreviewData(null);
        setImportSuccessMsg(null);
        setImportRejected([]);
        setImportWarnings([]);
        setImportStructureNote(null);
      }, 1200);
    } else {
      prepared.forEach(p => onAddProperty(p));
      setIsImportOpen(false);
      setImportPreviewData(null);
      setImportRejected([]);
      setImportWarnings([]);
      setImportStructureNote(null);
    }
  };

  return (
    <div id="properties-tab" className="space-y-8 animate-fade-in text-slate-100">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Mis Inmuebles Arrendados</h1>
          <p className="text-sm text-slate-400 mt-1">
            Gestiona tu cartera inmobiliaria, inquilinos, contratos e importes deducibles para el cálculo fiscal.
          </p>
        </div>
        {!isAdding && !editingId && (
          <div className="mt-4 sm:mt-0 flex flex-wrap items-center gap-2">
            {/* EXPORT BUTTON */}
            <button
              onClick={() => setIsExportOpen(true)}
              className="inline-flex items-center px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold rounded-xl transition-all cursor-pointer text-xs"
              title="Exportar inmuebles"
            >
              <Download className="w-4 h-4 mr-1.5 text-indigo-400" />
              <span>Exportar</span>
            </button>

            {/* IMPORT BUTTON */}
            <button
              onClick={() => {
                setIsImportOpen(true);
                setImportPreviewData(null);
                setImportError(null);
                setImportSuccessMsg(null);
                setImportRejected([]);
                setImportWarnings([]);
                setImportStructureNote(null);
              }}
              className="inline-flex items-center px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold rounded-xl transition-all cursor-pointer text-xs"
              title="Importar inmuebles"
            >
              <Upload className="w-4 h-4 mr-1.5 text-amber-400" />
              <span>Importar</span>
            </button>

            {/* ADD PROPERTY BUTTON */}
            <button
              onClick={() => { resetForm(); setIsAdding(true); }}
              className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition-all cursor-pointer text-xs shadow-md shadow-indigo-600/10"
            >
              <Plus className="w-4 h-4 mr-1.5" />
              <span>Añadir Inmueble</span>
            </button>
          </div>
        )}
      </div>

      {/* FORM: ADD OR EDIT */}
      {(isAdding || editingId) && (
        <form onSubmit={handleSubmit} className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 sm:p-8 space-y-6 animate-slide-in">
          <fieldset disabled={isSavingProperty} className="contents space-y-6">
          <div className="flex justify-between items-center border-b border-slate-700/60 pb-4">
            <h3 className="text-lg font-bold text-white flex items-center">
              <Building className="w-5 h-5 text-indigo-400 mr-2" />
              {editingId ? "Editar Detalles del Inmueble" : "Añadir Nuevo Inmueble de Alquiler"}
            </h3>
            <button
              type="button"
              onClick={() => { setIsAdding(false); setEditingId(null); resetForm(); }}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700/40"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* COLUMN 1: BASICS */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Dirección Completa</label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-slate-900/60 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-slate-100 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Calle de Alcalá 140, 3ºB, Madrid"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Referencia Catastral (20 caracteres)</label>
                <input
                  type="text"
                  value={cadastralReference}
                  onChange={(e) => setCadastralReference(e.target.value)}
                  className="w-full bg-slate-900/60 border border-slate-700 rounded-xl px-4 py-2.5 text-sm font-mono text-slate-100 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 uppercase"
                  placeholder="9872301VK4797S0003TR"
                  maxLength={20}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Titularidad Catastral</label>
                  <select
                    value={owner}
                    onChange={(e) => handleOwnerChange(e.target.value as any)}
                    className="w-full bg-slate-900/60 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-slate-100 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  >
                    <option value="user1">Propietario 1 ({user1Name})</option>
                    {hasPartner && <option value="user2">Propietario 2 ({user2Name})</option>}
                    {hasPartner && <option value="both">Coparticipado (Ambos)</option>}
                  </select>
                </div>

                {owner === 'both' && (
                  <div className="flex space-x-2">
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1.5">% {user1Name.split(" ")[0]}</label>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={pctU1}
                        onChange={(e) => {
                          const valStr = e.target.value;
                          if (valStr === "" || /^[0-9]*[.,]?[0-9]*$/.test(valStr)) {
                            const valNum = Math.min(100, Math.max(0, Number(valStr.replace(",", ".") || 0)));
                            setPctU1(valStr);
                            setPctU2((100 - valNum).toString());
                          }
                        }}
                        className="w-full bg-slate-900/60 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 font-bold focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1.5">% {user2Name.split(" ")[0]}</label>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={pctU2}
                        onChange={(e) => {
                          const valStr = e.target.value;
                          if (valStr === "" || /^[0-9]*[.,]?[0-9]*$/.test(valStr)) {
                            const valNum = Math.min(100, Math.max(0, Number(valStr.replace(",", ".") || 0)));
                            setPctU2(valStr);
                            setPctU1((100 - valNum).toString());
                          }
                        }}
                        className="w-full bg-slate-900/60 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 font-bold focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-slate-900/30 p-4 rounded-xl border border-slate-700/40 space-y-3">
                <h4 className="text-xs font-bold text-slate-300 flex items-center">
                  <User className="w-3.5 h-3.5 text-indigo-400 mr-1.5" />
                  Información de Contrato e Inquilino
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Nombre Completo de Inquilinos</label>
                    <input
                      type="text"
                      value={tenantName}
                      onChange={(e) => setTenantName(e.target.value)}
                      className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100"
                      placeholder="Juan Pérez García, María López Fernández"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">NIF / DNI de Inquilinos</label>
                    <input
                      type="text"
                      value={tenantDni}
                      onChange={(e) => setTenantDni(e.target.value)}
                      className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 font-mono"
                      placeholder="12345678Z, 87654321X"
                    />
                  </div>
                </div>
                <p className="text-[9px] text-slate-500 italic">
                  * Si hay varios inquilinos, sepáralos por comas (ej: Juan Pérez, María López).
                </p>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Renta Mensual (€/mes)</label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={monthlyRent}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === "" || /^[0-9]*[.,]?[0-9]*$/.test(val)) {
                        setMonthlyRent(val);
                      }
                    }}
                    className="w-1/2 bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 font-semibold focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                {/* Apartado para Contratos */}
                <div className="border-t border-slate-700/60 pt-3.5 mt-2 space-y-3">
                  <span className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider block">
                    Vigencia y Documentación de Contrato
                  </span>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">Fecha de Inicio</label>
                      <input
                        type="date"
                        value={contractStartDate}
                        onChange={(e) => setContractStartDate(e.target.value)}
                        className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">Fecha de Fin (si procede)</label>
                      <input
                        type="date"
                        value={contractEndDate}
                        onChange={(e) => setContractEndDate(e.target.value)}
                        className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Renta en Contrato (€/mes, opcional)</label>
                    <input
                      type="text"
                      inputMode="decimal"
                      placeholder={monthlyRent || "0"}
                      value={contractMonthlyRent}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "" || /^[0-9]*[.,]?[0-9]*$/.test(val)) {
                          setContractMonthlyRent(val);
                        }
                      }}
                      className="w-1/2 bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 font-semibold focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>

                  {/* Subida de Contrato PDF en Formulario */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] text-slate-400">Adjuntar Documento PDF de Contrato</label>
                    {contractPdfError && <p className="text-[10px] text-red-400">{contractPdfError}</p>}
                    <div className="relative border border-dashed border-slate-700 hover:border-slate-500 rounded-xl p-4 transition-all bg-slate-900/40 text-center">
                      <input
                        type="file"
                        accept=".pdf"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const invalid = validateAttachment(file);
                            if (invalid) {
                              setContractPdfError(invalid);
                              e.target.value = "";
                              return;
                            }
                            setContractPdfError(null);
                            setContractPdfFile(file);
                            setContractPdfPath("");
                            setContractPdfName(file.name);
                            const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
                            setContractPdfSize(`${sizeInMB} MB`);
                            if (!contractStartDate) {
                              setContractStartDate(new Date().toISOString().split('T')[0]);
                            }
                            if (!contractMonthlyRent) {
                              setContractMonthlyRent(monthlyRent || "1200");
                            }
                          }
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      
                      {contractPdfName ? (
                        <div className="flex items-center justify-between text-xs bg-slate-950/40 p-2.5 rounded-lg border border-slate-800">
                          <div className="flex items-center space-x-2">
                            <FileText className="w-5 h-5 text-emerald-400" />
                            <div className="text-left">
                              <p className="font-semibold text-slate-200 truncate max-w-[150px]">{contractPdfName}</p>
                              <p className="text-[10px] text-slate-500">{contractPdfSize || "Fichero PDF"}</p>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setContractPdfName("");
                              setContractPdfSize("");
                              setContractPdfFile(null);
                              setContractPdfPath("");
                            }}
                            className="text-red-400 hover:text-red-300 font-semibold text-[10px] uppercase tracking-wider"
                          >
                            Eliminar
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <Upload className="w-5 h-5 text-slate-500 mx-auto" />
                          <p className="text-[11px] text-slate-400 font-medium">Selecciona o arrastra el PDF del contrato</p>
                          <p className="text-[9px] text-slate-500">Admite archivos .pdf de hasta 10 MB</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* COLUMN 2: FINANCIAL DETAILS & TAX DEDUCTIONS */}
            <div className="space-y-4">
              <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-700/60 space-y-4">
                <h4 className="text-xs font-bold text-slate-300 flex items-center">
                  <Calculator className="w-3.5 h-3.5 text-indigo-400 mr-1.5" />
                  Base de Compra y Amortización Fiscal
                </h4>
                <p className="text-[10px] text-slate-400 leading-normal">
                  Según la normativa española de IRPF, es deducible como gasto el 3% del coste de adquisición correspondiente a la construcción (excluyendo el valor de suelo).
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Precio Compra / Adquisición (€)</label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={purchasePrice}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "" || /^[0-9]*[.,]?[0-9]*$/.test(val)) {
                          setPurchasePrice(val);
                        }
                      }}
                      className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 font-bold focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Porcentaje Suelo Catastral (%)</label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={landValuePercent}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "" || /^[0-9]*[.,]?[0-9]*$/.test(val)) {
                          setLandValuePercent(val);
                        }
                      }}
                      className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 font-semibold focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs bg-slate-950/40 p-3 rounded-lg border border-slate-800 text-indigo-300">
                  <span>Amortización Anual Deducible Estimada:</span>
                  <span className="font-bold text-white">
                    {((Number(purchasePrice.toString().replace(",", ".") || 0) * (100 - Number(landValuePercent.toString().replace(",", ".") || 0)) / 100) * 0.03).toLocaleString("es-ES")} €
                  </span>
                </div>
              </div>

              <div className="bg-slate-900/30 p-4 rounded-xl border border-slate-700/40 space-y-3">
                <h4 className="text-xs font-bold text-slate-300 flex items-center">
                  <Coins className="w-3.5 h-3.5 text-indigo-400 mr-1.5" />
                  Gastos Anuales Estimados (Deducibles de Renta)
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Gastos de Comunidad (€/año)</label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={expensesCommunity}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "" || /^[0-9]*[.,]?[0-9]*$/.test(val)) {
                          setExpensesCommunity(val);
                        }
                      }}
                      className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Importe IBI (€/año)</label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={expensesIBI}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "" || /^[0-9]*[.,]?[0-9]*$/.test(val)) {
                          setExpensesIBI(val);
                        }
                      }}
                      className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Seguro de Hogar / Impago (€/año)</label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={expensesInsurance}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "" || /^[0-9]*[.,]?[0-9]*$/.test(val)) {
                          setExpensesInsurance(val);
                        }
                      }}
                      className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Reparaciones y Conservación (€/año)</label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={expensesRepairs}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === "" || /^[0-9]*[.,]?[0-9]*$/.test(val)) {
                          setExpensesRepairs(val);
                        }
                      }}
                      className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* ACTIONS */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-slate-700/60">
            <button
              type="button"
              onClick={() => { setIsAdding(false); setEditingId(null); resetForm(); }}
              className="px-5 py-2 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-700/40 text-sm transition-all cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSavingProperty}
              className="inline-flex items-center px-6 py-2 disabled:opacity-60 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-sm transition-all cursor-pointer shadow-lg shadow-indigo-600/10"
            >
              <Check className="w-4 h-4 mr-1.5" />
              <span>{editingId ? "Sincronizar Cambios" : "Guardar e Integrar"}</span>
            </button>
          </div>
          </fieldset>
        </form>
      )}

      {/* PROPERTY LIST CARDS */}
      {!isAdding && !editingId && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {properties.length > 0 ? (
            properties.map((prop) => {
              const isFiscalOpen = openFiscalPropertyId === prop.id;
              
              // Calculate values specifically for the selected year
              const propertyExpensesForYear = expenses.filter(
                (e) => e.propertyId === prop.id && parseInt(e.date.split("-")[0] || "0") === fiscalFilterYear
              );

              const dynamicRepairs = propertyExpensesForYear.filter(e => e.category === 'repairs').reduce((sum, e) => sum + e.amount, 0);
              const dynamicIBI = propertyExpensesForYear.filter(e => e.category === 'ibi').reduce((sum, e) => sum + e.amount, 0);
              const dynamicInsurance = propertyExpensesForYear.filter(e => e.category === 'insurance').reduce((sum, e) => sum + e.amount, 0);
              const dynamicCommunity = propertyExpensesForYear.filter(e => e.category === 'community').reduce((sum, e) => sum + e.amount, 0);
              const dynamicMaintenance = propertyExpensesForYear.filter(e => e.category === 'maintenance').reduce((sum, e) => sum + e.amount, 0);
              const dynamicAmortization = propertyExpensesForYear.filter(e => e.category === 'amortization').reduce((sum, e) => sum + e.amount, 0);
              const dynamicOther = propertyExpensesForYear.filter(e => e.category === 'other').reduce((sum, e) => sum + e.amount, 0);

              const is2025 = fiscalFilterYear === 2025;
              const totalRepairs = is2025 ? prop.expensesRepairs : dynamicRepairs;
              const totalIBI = is2025 ? prop.expensesIBI : dynamicIBI;
              const totalInsurance = is2025 ? prop.expensesInsurance : dynamicInsurance;
              const totalCommunity = is2025 ? prop.expensesCommunity : dynamicCommunity;
              const totalAmortization = is2025 ? prop.amortizationAmount : dynamicAmortization;
              const totalMaintenance = dynamicMaintenance;
              const totalOther = dynamicOther;

              const grandTotalExpenses = totalRepairs + totalIBI + totalInsurance + totalCommunity + totalAmortization + totalMaintenance + totalOther;

              const isFinancialsOpen = openFinancialsPropertyId === prop.id;
              const isDocsOpen = openDocsPropertyId === prop.id;
              const isExpanded = isFiscalOpen || openContractPropertyId === prop.id || isFinancialsOpen || isDocsOpen;

              return (
                <div 
                  key={prop.id} 
                  className={`bg-slate-800/40 border border-slate-700/50 hover:border-slate-600 rounded-2xl p-6 transition-all shadow-lg flex flex-col justify-between space-y-6 relative group ${
                    isExpanded ? "md:col-span-2 border-indigo-500/50 shadow-indigo-950/20" : ""
                  }`}
                >
                  
                  {/* Upper Card Block */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-start space-x-3 min-w-0">
                        <div className="p-2.5 bg-indigo-600/10 text-indigo-400 rounded-xl border border-indigo-500/10 shrink-0">
                          <Building className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-md font-bold text-white leading-tight pr-8 truncate" title={prop.address}>{prop.address}</h4>
                          <div className="flex items-center space-x-2 mt-1 text-xs text-slate-400 font-mono">
                            <MapPin className="w-3 h-3 text-slate-500" />
                            <span className="truncate">Ref: {prop.cadastralReference || "No asignada"}</span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => onDeleteProperty(prop.id)}
                        className="text-slate-500 hover:text-red-400 p-1.5 rounded-lg hover:bg-slate-700/30 transition-all shrink-0 cursor-pointer"
                        title="Eliminar Inmueble"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Badges / Titularidades */}
                    <div className="flex flex-wrap gap-2 text-[10px] font-mono font-semibold">
                      <span className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg text-indigo-400">
                        Propietario: {prop.owner === 'user1' ? user1Name.split(" ")[0] : prop.owner === 'user2' ? user2Name.split(" ")[0] : "Ambos"}
                      </span>
                      {prop.owner === 'both' && (
                        <span className="px-2.5 py-1 bg-indigo-950/40 border border-indigo-500/20 rounded-lg text-white">
                          {user1Name.split(" ")[0]}: {prop.ownershipPercentageUser1}% | {user2Name.split(" ")[0]}: {prop.ownershipPercentageUser2}%
                        </span>
                      )}
                      {(() => {
                        const todayStr = new Date().toISOString().split("T")[0];
                        const isContractActive = prop.contract && (!prop.contract.endDate || prop.contract.endDate >= todayStr);
                        if (isContractActive) {
                          return (
                            <span className="px-2.5 py-1 bg-emerald-950/40 border border-emerald-500/20 rounded-lg text-emerald-400 flex items-center">
                              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse mr-1.5"></span>
                              <span>Contrato Activo</span>
                            </span>
                          );
                        } else if (prop.contract) {
                          return (
                            <span className="px-2.5 py-1 bg-amber-950/20 border border-amber-500/20 rounded-lg text-amber-500 flex items-center">
                              <span className="w-1.5 h-1.5 bg-amber-400 rounded-full mr-1.5"></span>
                              <span>Contrato Vencido</span>
                            </span>
                          );
                        } else {
                          return (
                            <span className="px-2.5 py-1 bg-amber-950/20 border border-amber-500/20 rounded-lg text-amber-500">
                              Sin Contrato
                            </span>
                          );
                        }
                      })()}
                    </div>

                    {/* Financial Metrics Split */}
                    <div className="grid grid-cols-2 gap-4 bg-slate-900/30 p-4 rounded-xl border border-slate-700/20 text-xs">
                      <div className="space-y-1">
                        <span className="text-slate-500 font-mono uppercase block text-[9px]">Renta Mensual</span>
                        <span className="text-lg font-black text-white">{prop.monthlyRent.toLocaleString("es-ES")} €</span>
                      </div>
                      <div className="space-y-1">
                        <span className="text-slate-500 font-mono uppercase block text-[9px]">Amortización Anual</span>
                        <span className="text-lg font-bold text-indigo-300">{prop.amortizationAmount.toLocaleString("es-ES")} €</span>
                      </div>
                    </div>

                    {/* Inquilinos info */}
                    {(() => {
                      const history: TenantContractRecord[] = prop.tenantHistory && prop.tenantHistory.length > 0
                        ? prop.tenantHistory
                        : (prop.tenantName ? [{
                            id: `rec_${prop.id}`,
                            tenantName: prop.tenantName,
                            tenantDni: prop.tenantDni || "",
                            startDate: prop.contract?.startDate || "2024-01-01",
                            endDate: prop.contract?.endDate,
                            monthlyRent: prop.contract?.monthlyRent || prop.monthlyRent || 0
                          }] : []);

                      return (
                        <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-800 space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                              Historial de Inquilinos ({history.length})
                            </span>
                            {history.length > 1 && (
                              <span className="text-[9px] bg-amber-500/10 text-amber-300 border border-amber-500/20 px-1.5 py-0.5 rounded font-mono font-bold">
                                Cambio Registrado
                              </span>
                            )}
                          </div>

                          {history.length > 0 ? (
                            <div className="space-y-1.5 max-h-[140px] overflow-y-auto">
                              {history.map((tRec, idx) => {
                                const todayStr = new Date().toISOString().split("T")[0];
                                const isCurrent = idx === history.length - 1 && (!tRec.endDate || tRec.endDate >= todayStr);
                                return (
                                  <div 
                                    key={tRec.id || idx} 
                                    className={`p-2 rounded-lg border text-xs space-y-1 ${
                                      isCurrent 
                                        ? "bg-emerald-950/20 border-emerald-500/30 text-slate-200" 
                                        : "bg-slate-900/40 border-slate-800 text-slate-400"
                                    }`}
                                  >
                                    <div className="flex justify-between items-center">
                                      <div className="flex items-center space-x-1.5 min-w-0">
                                        <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isCurrent ? "bg-emerald-400" : "bg-slate-500"}`}></span>
                                        <span className="font-semibold text-white truncate max-w-[130px]">{tRec.tenantName}</span>
                                        {tRec.tenantDni && (
                                          <span className="text-[9px] text-slate-500 font-mono">({tRec.tenantDni})</span>
                                        )}
                                      </div>
                                      <div className="flex items-center gap-1">
                                        <span className={`text-[8px] px-1.5 py-0.5 rounded font-mono font-bold ${
                                          isCurrent ? "bg-emerald-500/10 text-emerald-300 border border-emerald-500/20" : "bg-slate-800 text-slate-400"
                                        }`}>
                                          {isCurrent ? "Vigente" : "Anterior"}
                                        </span>
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleDeleteTenantRecord(prop, tRec.id, idx);
                                          }}
                                          className="p-1 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded transition-colors cursor-pointer"
                                          title="Eliminar este inquilino del historial"
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </button>
                                      </div>
                                    </div>

                                    <div className="flex justify-between items-center text-[9px] text-slate-400 font-mono">
                                      <span>
                                        {tRec.startDate ? tRec.startDate.split("-").reverse().join("/") : "---"} 
                                        {tRec.endDate ? ` ➔ ${tRec.endDate.split("-").reverse().join("/")}` : " ➔ Vigente"}
                                      </span>
                                      <span className="font-bold text-indigo-300">{(tRec.monthlyRent || prop.monthlyRent).toLocaleString("es-ES")} €/m</span>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          ) : (
                            <p className="text-xs text-slate-500 italic">No se especifican inquilinos</p>
                          )}
                        </div>
                      );
                    })()}
                  </div>

                  {/* Lower Card Block: Expenses Overview & Action Buttons */}
                  <div className="space-y-4 pt-4 border-t border-slate-700/40">
                    <div className="flex justify-between items-center text-xs text-slate-400">
                      <span>Deducciones e Impuestos ({fiscalFilterYear}):</span>
                      <span className="font-semibold text-indigo-300">
                        {grandTotalExpenses.toLocaleString("es-ES")} € desgravables
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleStartEdit(prop)}
                        className="inline-flex items-center justify-center py-2 px-3 bg-slate-900 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 text-slate-300 font-semibold rounded-xl text-xs transition-all cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5 mr-1" />
                        Editar Ficha
                      </button>

                      <button
                        onClick={() => {
                          setOpenFinancialsPropertyId(isFinancialsOpen ? null : prop.id);
                          setOpenDocsPropertyId(null);
                          setOpenFiscalPropertyId(null);
                          setOpenContractPropertyId(null);
                        }}
                        className={`inline-flex items-center justify-center py-2 px-3 border rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          isFinancialsOpen
                            ? "bg-amber-600 hover:bg-amber-500 border-amber-500 text-slate-950 font-bold"
                            : "bg-amber-950/20 hover:bg-amber-950/40 border-amber-500/20 text-amber-400"
                        }`}
                      >
                        <Coins className="w-3.5 h-3.5 mr-1" />
                        Finanzas/Hipoteca 💰
                      </button>

                      <button
                        disabled={docIsSaving || cardIsSaving}
                        onClick={() => {
                          setOpenDocsPropertyId(isDocsOpen ? null : prop.id);
                          setOpenFinancialsPropertyId(null);
                          setOpenFiscalPropertyId(null);
                          setOpenContractPropertyId(null);
                        }}
                        className={`inline-flex items-center justify-center py-2 px-3 border rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          isDocsOpen
                            ? "bg-blue-600 hover:bg-blue-500 border-blue-500 text-white font-bold"
                            : "bg-blue-950/20 hover:bg-blue-950/40 border-blue-500/20 text-blue-400"
                        }`}
                      >
                        <Upload className="w-3.5 h-3.5 mr-1" />
                        Recibos/Docs 📁
                      </button>

                      <button
                        onClick={() => {
                          handleToggleContractPanel(prop);
                          setOpenFinancialsPropertyId(null);
                          setOpenDocsPropertyId(null);
                          setOpenFiscalPropertyId(null);
                        }}
                        className={`inline-flex items-center justify-center py-2 px-3 border rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          openContractPropertyId === prop.id
                            ? "bg-emerald-600 hover:bg-emerald-500 border-emerald-500 text-slate-950 font-bold"
                            : "bg-emerald-950/20 hover:bg-emerald-950/40 border-emerald-500/20 text-emerald-400"
                        }`}
                      >
                        <FileText className="w-3.5 h-3.5 mr-1" />
                        Contrato 📄
                      </button>
                      
                      <button
                        onClick={() => {
                          setOpenFiscalPropertyId(isFiscalOpen ? null : prop.id);
                          setOpenContractPropertyId(null);
                          setOpenFinancialsPropertyId(null);
                          setOpenDocsPropertyId(null);
                        }}
                        className={`col-span-2 inline-flex items-center justify-center py-2 px-3 border rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          isFiscalOpen 
                            ? "bg-indigo-600 hover:bg-indigo-500 border-indigo-500 text-white" 
                            : "bg-indigo-950/20 hover:bg-indigo-950/40 border-indigo-500/20 text-indigo-400"
                        }`}
                      >
                        <Calculator className="w-3.5 h-3.5 mr-1" />
                        Opción Fiscal 📊
                      </button>
                    </div>
                  </div>

                  {/* BLOC FINANCIERO E HIPOTECARIO EXPANDIDO */}
                  {isFinancialsOpen && (
                    <div className="w-full bg-slate-900/80 border border-amber-500/20 rounded-2xl p-5 mt-4 space-y-4 animate-slide-in text-left">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-800 pb-3 gap-2">
                        <div className="flex items-center space-x-2">
                          <Coins className="w-5 h-5 text-amber-400" />
                          <div>
                            <h5 className="text-sm font-bold text-white">Análisis Financiero, Tasación e Hipoteca ({financialYear})</h5>
                            <p className="text-[10px] text-slate-400">Control de plusvalías latentes, endeudamiento y rentabilidad anual de este inmueble.</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 shrink-0">
                          <span className="text-[11px] text-slate-400">Cambiar Año:</span>
                          <select
                            value={financialYear}
                            onChange={(e) => setFinancialYear(Number(e.target.value))}
                            className="bg-slate-950 border border-slate-800 text-xs text-white font-bold px-2 py-1.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500"
                          >
                            <option value="2025">2025</option>
                            <option value="2026">2026</option>
                            <option value="2027">2027</option>
                            <option value="2028">2028</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                        {/* Formulario Izquierda */}
                        <div className="space-y-3.5">
                          <div>
                            <label className="block text-[10px] text-slate-400 uppercase font-mono mb-1">Valor de Mercado Actual Estimado (€)</label>
                            <input
                              type="text"
                              inputMode="decimal"
                              value={finCurrentValue}
                              onChange={(e) => setFinCurrentValue(e.target.value)}
                              placeholder={(prop.purchasePrice || 0).toString()}
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-amber-500 font-bold"
                            />
                            <p className="text-[9px] text-slate-500 mt-0.5">El valor estimado si lo vendieses hoy. Afecta al Equity y al ROE.</p>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] text-slate-400 uppercase font-mono mb-1">Precio de Compra (€)</label>
                              <input
                                type="text"
                                inputMode="decimal"
                                value={finPurchasePrice}
                                onChange={(e) => setFinPurchasePrice(e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-amber-500 font-semibold"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-slate-400 uppercase font-mono mb-1">Gastos de Compra (€)</label>
                              <input
                                type="text"
                                inputMode="decimal"
                                value={finPurchaseExpenses}
                                onChange={(e) => setFinPurchaseExpenses(e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-amber-500 font-semibold"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <label className="block text-[10px] text-slate-400 uppercase font-mono">Capital Hipoteca Pendiente (€)</label>
                                {isMortgageCalculatedState ? (
                                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 font-medium">
                                    🔵 Proyección
                                  </span>
                                ) : (
                                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium">
                                    🟢 Dato Real / Manual
                                  </span>
                                )}
                              </div>
                              <input
                                type="text"
                                inputMode="decimal"
                                value={finMortgageDebt}
                                onChange={(e) => {
                                  setFinMortgageDebt(e.target.value);
                                  setIsMortgageCalculatedState(false);
                                }}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-amber-500 font-semibold"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-slate-400 uppercase font-mono mb-1">Cuota Mensual Hipoteca (€)</label>
                              <input
                                type="text"
                                inputMode="decimal"
                                value={finMonthlyMortgagePayment}
                                onChange={(e) => setFinMonthlyMortgagePayment(e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-amber-500 font-semibold"
                              />
                            </div>
                          </div>

                          <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 space-y-2">
                            <div className="text-[10px] font-bold text-amber-400 font-mono uppercase tracking-wider">
                              ⚙️ Amortización Hipotecaria (Calculadora Sistema Francés)
                            </div>
                            <div className="grid grid-cols-3 gap-2">
                              <div>
                                <label className="block text-[9px] text-slate-400 font-mono mb-0.5">Tipo Interés Anual (%)</label>
                                <input
                                  type="text"
                                  inputMode="decimal"
                                  placeholder="Ej: 3.25"
                                  value={finInterestRate}
                                  onChange={(e) => setFinInterestRate(e.target.value)}
                                  className="w-full bg-slate-950 border border-slate-800 rounded-md px-2 py-1 text-xs text-amber-300 font-semibold"
                                />
                              </div>
                              <div>
                                <label className="block text-[9px] text-slate-400 font-mono mb-0.5">Fecha Referencia</label>
                                <input
                                  type="date"
                                  value={finStartDate}
                                  onChange={(e) => setFinStartDate(e.target.value)}
                                  className="w-full bg-slate-950 border border-slate-800 rounded-md px-2 py-1 text-xs text-slate-300"
                                />
                              </div>
                              <div>
                                <label className="block text-[9px] text-slate-400 font-mono mb-0.5">Plazo Total (Años)</label>
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  placeholder="Ej: 25"
                                  value={finTermYears}
                                  onChange={(e) => setFinTermYears(e.target.value)}
                                  className="w-full bg-slate-950 border border-slate-800 rounded-md px-2 py-1 text-xs text-slate-300"
                                />
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              handleSaveFinancials(prop);
                              alert(`Datos financieros del año ${financialYear} guardados y actualizados exitosamente.`);
                            }}
                            className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Guardar Finanzas de {financialYear} 💰</span>
                          </button>
                        </div>

                        {/* Métricas e Indicadores de Rendimiento Derecha */}
                        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 space-y-3 flex flex-col justify-between">
                          <h6 className="text-[11px] font-bold text-amber-300 font-mono uppercase tracking-wider">Métricas Clave de Inversión ({financialYear})</h6>
                          
                          {(() => {
                            const curVal = Number(finCurrentValue.replace(",", ".") || 0) || prop.purchasePrice || 0;
                            const purPrice = Number(finPurchasePrice.replace(",", ".") || 0) || prop.purchasePrice || 0;
                            const purExp = Number(finPurchaseExpenses.replace(",", ".") || 0);
                            const mortDebt = Number(finMortgageDebt.replace(",", ".") || 0);
                            const mortPay = Number(finMonthlyMortgagePayment.replace(",", ".") || 0);

                            const totalInvestment = purPrice + purExp;
                            const equity = curVal - mortDebt;
                            const equityPercent = curVal > 0 ? (equity / curVal) * 100 : 0;

                            // Rent estimates
                            const monthlyRentEstimate = prop.contract?.monthlyRent ?? prop.monthlyRent ?? 0;
                            const annualRent = monthlyRentEstimate * 12;

                            // Annual expenses for this year
                            const annualExp = grandTotalExpenses;
                            
                            // Gross & Net Yields
                            const grossYield = totalInvestment > 0 ? (annualRent / totalInvestment) * 100 : 0;
                            const netYield = totalInvestment > 0 ? ((annualRent - annualExp) / totalInvestment) * 100 : 0;

                            // Cashflow: prorating community, IBI, insurance over 12 months, and subtracting them and mortgage
                            const communityMonthly = (totalCommunity || 0) / 12;
                            const ibiMonthly = (totalIBI || 0) / 12;
                            const insuranceMonthly = (totalInsurance || 0) / 12;
                            const cashflow = monthlyRentEstimate - mortPay - communityMonthly - ibiMonthly - insuranceMonthly;

                            // ROE & TIR
                            const capInvertido = Math.max(1000, totalInvestment - mortDebt);
                            const annualCashflow = cashflow * 12;
                            const roe = capInvertido > 0 ? (annualCashflow / capInvertido) * 100 : 0;
                            const tir = capInvertido > 0 ? ((annualCashflow + (curVal * 0.035)) / capInvertido) * 100 : 0;

                            return (
                              <div className="space-y-2.5 text-xs text-slate-300">
                                <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
                                  <span>Equity de la propiedad:</span>
                                  <span className="font-bold text-white">
                                    {equity.toLocaleString("es-ES")} € <span className="text-[10px] text-slate-500 font-mono">({Math.round(equityPercent)}%)</span>
                                  </span>
                                </div>
                                <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
                                  <span>Cashflow Neto Mensual:</span>
                                  <span className={`font-black ${cashflow >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                    {cashflow >= 0 ? '+' : ''}{cashflow.toLocaleString("es-ES", { maximumFractionDigits: 2 })} €/mes
                                  </span>
                                </div>
                                <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
                                  <span>Rentabilidad Bruta:</span>
                                  <span className="font-bold text-white">{grossYield.toFixed(2)} %</span>
                                </div>
                                <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
                                  <span>Rentabilidad Neta:</span>
                                  <span className="font-bold text-amber-400">{netYield.toFixed(2)} %</span>
                                </div>
                                <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
                                  <span>ROE (s/ capital propio):</span>
                                  <span className="font-semibold text-indigo-300">{roe.toFixed(2)} %</span>
                                </div>
                                <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
                                  <span className="flex items-center">
                                    TIR Anual Estimada:
                                    <span className="group/tir relative ml-1 cursor-help text-slate-500 hover:text-indigo-400">
                                      <Info className="w-3 h-3" />
                                      <span className="absolute bottom-full right-0 mb-1 w-44 p-1.5 bg-slate-950 text-[9px] text-slate-400 rounded-lg opacity-0 group-hover/tir:opacity-100 transition-all pointer-events-none shadow-xl border border-slate-800 leading-tight">
                                        Calculada con cashflow neto más una apreciación histórica anual estimada del 3,5%.
                                      </span>
                                    </span>
                                  </span>
                                  <span className="font-bold text-emerald-400">{tir.toFixed(2)} %</span>
                                </div>
                                <div className="bg-slate-900/60 p-2 rounded-lg text-[10px] text-slate-400 border border-slate-900">
                                  <span className="font-bold text-slate-300 block mb-1">Gasto total en este ejercicio ({financialYear}):</span>
                                  {grandTotalExpenses > 0 ? (
                                    <span>
                                      Un total de <strong className="text-white">{grandTotalExpenses.toLocaleString("es-ES")} €</strong> imputados: Comunidad ({totalCommunity}€), IBI ({totalIBI}€), Seguros ({totalInsurance}€), Reparaciones ({totalRepairs}€), Amortización ({totalAmortization}€).
                                    </span>
                                  ) : (
                                    <span>Sin gastos declarados en el libro para el año {financialYear}.</span>
                                  )}
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* BLOC RECIBOS Y DOCUMENTOS EXPANDIDO */}
                  {isDocsOpen && (
                    <fieldset disabled={docIsSaving} className="w-full min-w-0 bg-slate-900/80 border border-blue-500/20 rounded-2xl p-5 mt-4 space-y-4 animate-slide-in text-left">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-800 pb-3 gap-2">
                        <div className="flex items-center space-x-2">
                          <Upload className="w-5 h-5 text-blue-400" />
                          <div>
                            <h5 className="text-sm font-bold text-white">Archivo Digital de Recibos y Comprobantes ({docYear})</h5>
                            <p className="text-[10px] text-slate-400">Guarda tus justificantes fiscales (IBI, seguro, comunidad) listos para requerimientos de la AEAT.</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 shrink-0">
                          <span className="text-[11px] text-slate-400">Asignar Año:</span>
                          <select
                            value={docYear}
                            onChange={(e) => setDocYear(Number(e.target.value))}
                            className="bg-slate-950 border border-slate-800 text-xs text-white font-bold px-2 py-1.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                          >
                            <option value="2025">2025</option>
                            <option value="2026">2026</option>
                            <option value="2027">2027</option>
                            <option value="2028">2028</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                        {/* Subir Documento */}
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <label className="block text-xs font-semibold text-slate-300">1. Seleccionar Categoría del Recibo/Documento</label>
                            <select
                              value={docCategory}
                              onChange={(e) => setDocCategory(e.target.value as any)}
                              className="w-full bg-slate-950 border border-slate-800 text-xs text-white rounded-lg p-2 focus:ring-1 focus:ring-blue-500 font-bold"
                            >
                              <option value="ibi">Impuesto de Bienes Inmuebles (IBI) 🏦</option>
                              <option value="seguros">Seguro del Hogar / Impago de Alquiler 🛡️</option>
                              <option value="comunidad">Gastos de Comunidad de Propietarios 👥</option>
                              <option value="reparaciones">Facturas de Reparaciones / Reformas 🔧</option>
                              <option value="muebles_electrodomesticos">Facturas de Muebles o Electrodomésticos 📺</option>
                              <option value="otros">Otros Justificantes / Gastos Administrativos 📝</option>
                            </select>
                          </div>

                          <div className="space-y-2">
                            <label className="block text-xs font-semibold text-slate-300">2. Cargar Recibo (Formatos PDF, JPG, PNG)</label>
                            <div className="relative border border-dashed border-slate-800 hover:border-blue-500/50 rounded-xl p-6 transition-all bg-slate-950/40 text-center">
                              <input
                                type="file"
                                accept=".pdf,image/jpeg,image/png"
                                onChange={handleUploadDocLocal}
                                disabled={docIsSaving}
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                              />
                              {docIsUploading ? (
                                <div className="space-y-2">
                                  <Loader2 className="w-6 h-6 text-blue-400 animate-spin mx-auto" />
                                  <p className="text-[11px] text-slate-300">Cargando archivo local...</p>
                                </div>
                              ) : pendingDocFile ? (
                                <div className="space-y-1.5">
                                  <div className="flex items-center justify-center space-x-1 text-emerald-400">
                                    <CheckCircle className="w-4 h-4" />
                                    <span className="text-[11px] font-bold">Archivo seleccionado; pendiente de guardar</span>
                                  </div>
                                  <p className="text-xs font-semibold text-slate-200 truncate max-w-[240px] mx-auto">{uploadedFileName}</p>
                                  <p className="text-[10px] text-slate-500 font-mono">{uploadedFileSize}</p>
                                </div>
                              ) : (
                                <div className="space-y-1">
                                  <Upload className="w-6 h-6 text-slate-600 mx-auto" />
                                  <p className="text-xs text-slate-300 font-medium">Examinar o soltar archivo</p>
                                  <p className="text-[9px] text-slate-500">PDF, JPG o PNG hasta 10MB</p>
                                </div>
                              )}
                            </div>
                          </div>

                          {docError && <p role="alert" className="text-xs text-rose-300">{docError}</p>}
                          <button
                            type="button"
                            disabled={!pendingDocFile || docIsSaving}
                            onClick={async () => {
                              const ok = await handleSaveDocument(prop);
                              if (ok) alert("Documento verificado y asociado al inmueble en almacenamiento remoto.");
                            }}
                            className="w-full py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Integrar Documento en {docYear} 📂</span>
                          </button>
                        </div>

                        {/* Listado de Documentos del Año */}
                        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 space-y-3.5 flex flex-col justify-between">
                          <div>
                            <h6 className="text-[11px] font-bold text-blue-300 font-mono uppercase tracking-wider mb-2.5">Repositorio de Archivos ({docYear})</h6>
                            
                            {(() => {
                              const docsForYear = (prop.documents || []).filter(d => d.year === docYear);
                              if (docsForYear.length === 0) {
                                return (
                                  <div className="py-12 text-center text-slate-600 text-xs">
                                    No hay recibos digitalizados para el año {docYear} en este inmueble.
                                  </div>
                                );
                              }
                              return (
                                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                                  {docsForYear.map((doc) => {
                                    const catLabels: Record<string, string> = {
                                      ibi: 'IBI 🏦',
                                      seguros: 'Seguro 🛡️',
                                      comunidad: 'Comun. 👥',
                                      reparaciones: 'Repar. 🔧',
                                      muebles_electrodomesticos: 'Equipam. 📺',
                                      otros: 'Otros 📝'
                                    };
                                    return (
                                      <div key={doc.id} className="flex justify-between items-center bg-slate-900 border border-slate-800 p-2.5 rounded-xl text-xs">
                                        <div className="min-w-0 pr-2">
                                          <div className="flex items-center space-x-1.5">
                                            <span className="text-[9px] px-1.5 py-0.5 bg-blue-500/10 text-blue-400 border border-blue-500/10 rounded-md font-mono font-bold uppercase whitespace-nowrap">
                                              {catLabels[doc.category] || doc.category}
                                            </span>
                                            <p className="font-semibold text-slate-200 truncate" title={doc.name}>
                                              {doc.name}
                                            </p>
                                          </div>
                                          <p className="text-[10px] text-slate-500 mt-0.5">{doc.size} • Subido el {doc.uploadDate}</p>
                                        </div>
                                        
                                        <div className="flex items-center space-x-1.5 shrink-0">
                                          <button
                                            type="button"
                                            onClick={() => downloadAttachment({ vaultId: doc.vaultId, storagePath: doc.storagePath, inlineData: doc.fileData, fileName: doc.name }).catch((err) => alert(err instanceof Error ? err.message : "No se pudo descargar el documento."))}
                                            className="px-2 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-[10px] text-blue-400 hover:text-blue-300 font-bold rounded-lg cursor-pointer"
                                          >
                                            Descargar / Imprimir
                                          </button>
                                          
                                          {deleteExpenseConfirmId === doc.id ? (
                                            <div className="flex items-center space-x-1 bg-rose-950/20 border border-rose-500/20 p-0.5 rounded-lg">
                                              <button
                                                onClick={() => {
                                                  handleDeleteDocument(prop, doc.id);
                                                  setDeleteExpenseConfirmId(null);
                                                }}
                                                className="px-1 py-0.5 text-[8px] bg-rose-600 hover:bg-rose-500 text-white font-bold rounded"
                                              >
                                                Sí
                                              </button>
                                              <button
                                                onClick={() => setDeleteExpenseConfirmId(null)}
                                                className="px-1 py-0.5 text-[8px] bg-slate-800 text-slate-300 rounded"
                                              >
                                                No
                                              </button>
                                            </div>
                                          ) : (
                                            <button
                                              onClick={() => setDeleteExpenseConfirmId(doc.id)}
                                              className="p-1 text-slate-500 hover:text-rose-400 cursor-pointer"
                                              title="Eliminar documento"
                                            >
                                              <Trash2 className="w-3.5 h-3.5" />
                                            </button>
                                          )}
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              );
                            })()}
                          </div>
                          
                          <div className="text-[10px] text-slate-500 bg-slate-900/40 p-2 rounded-lg border border-slate-900 leading-normal">
                            💡 <strong>Prueba de Auditoría AEAT:</strong> Estos recibos coinciden con las deducciones cargadas en la opción fiscal y el libro de gastos. Puedes descargarlos de forma masiva ante cualquier requerimiento de inspección fiscal.
                          </div>
                        </div>
                      </div>
                    </fieldset>
                  )}

                  {/* BLOC FISCAL EXPANDIDO ALINEADO CON EL MODELO 100 */}
                  {isFiscalOpen && (
                    <div className="w-full bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 mt-4 space-y-4 animate-slide-in text-left">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-800 pb-3 gap-2">
                        <div className="flex items-center space-x-2">
                          <Calculator className="w-5 h-5 text-indigo-400" />
                          <div>
                            <h5 className="text-sm font-bold text-white">Declaración Fiscal de Gastos (IRPF {fiscalFilterYear})</h5>
                            <p className="text-[10px] text-slate-400">Todos los gastos categorizados e imputables para desgravar en tu renta.</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 shrink-0">
                          <span className="text-[11px] text-slate-400">Filtrar Año:</span>
                          <select
                            value={fiscalFilterYear}
                            onChange={(e) => setFiscalFilterYear(Number(e.target.value))}
                            className="bg-slate-950 border border-slate-800 text-xs text-white font-bold px-2 py-1.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          >
                            <option value="2025">2025</option>
                            <option value="2026">2026</option>
                            <option value="2027">2027</option>
                            <option value="2028">2028</option>
                          </select>
                        </div>
                      </div>

                      {/* Summary metrics of the year */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-1.5">
                        <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-800/60 text-xs">
                          <span className="text-slate-500 block text-[9px] uppercase font-mono">Gastos Comunidad</span>
                          <span className="text-sm font-bold text-white">{totalCommunity.toLocaleString("es-ES")} €</span>
                        </div>
                        <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-800/60 text-xs">
                          <span className="text-slate-500 block text-[9px] uppercase font-mono">Impuestos/IBI</span>
                          <span className="text-sm font-bold text-white">{totalIBI.toLocaleString("es-ES")} €</span>
                        </div>
                        <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-800/60 text-xs">
                          <span className="text-slate-500 block text-[9px] uppercase font-mono">Reparaciones/Conserv.</span>
                          <span className="text-sm font-bold text-white">{totalRepairs.toLocaleString("es-ES")} €</span>
                        </div>
                        <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-800/60 text-xs">
                          <span className="text-indigo-400 block text-[9px] uppercase font-mono">Total Deductible</span>
                          <span className="text-sm font-bold text-emerald-400">{grandTotalExpenses.toLocaleString("es-ES")} €</span>
                        </div>
                      </div>

                      {/* Categorized detailed AEAT lines */}
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs min-w-[500px]">
                          <thead>
                            <tr className="border-b border-slate-800 text-slate-500 font-mono text-[9px] uppercase">
                              <th className="py-2.5 px-3">Categoría Fiscal / Concepto AEAT</th>
                              <th className="py-2.5 px-3 text-right">Ficha (Estimación)</th>
                              <th className="py-2.5 px-3 text-right">Cargados (IA/Diario)</th>
                              <th className="py-2.5 px-3 text-right text-white font-semibold">Total Imputable</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60 text-slate-300 font-sans">
                            
                            {/* Repairs */}
                            <tr className="hover:bg-slate-800/20">
                              <td className="py-2.5 px-3">
                                <span className="block font-medium text-slate-200">Conservación y reparación</span>
                                <span className="text-[10px] text-slate-500">Pintura, averías de termos, fontanería, mantenimiento estético</span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono">{(is2025 ? prop.expensesRepairs : 0).toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-slate-400">{dynamicRepairs.toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-indigo-400 font-bold">{totalRepairs.toLocaleString("es-ES")} €</td>
                            </tr>

                            {/* Taxes */}
                            <tr className="hover:bg-slate-800/20">
                              <td className="py-2.5 px-3">
                                <span className="block font-medium text-slate-200">Tributos, recargos y tasas</span>
                                <span className="text-[10px] text-slate-500">IBI anual, tasas de basuras, vados municipales</span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono">{(is2025 ? prop.expensesIBI : 0).toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-slate-400">{dynamicIBI.toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-indigo-400 font-bold">{totalIBI.toLocaleString("es-ES")} €</td>
                            </tr>

                            {/* Insurance */}
                            <tr className="hover:bg-slate-800/20">
                              <td className="py-2.5 px-3">
                                <span className="block font-medium text-slate-200">Primas de contratos de seguro</span>
                                <span className="text-[10px] text-slate-500">Seguro multirriesgo del hogar, seguros de impago de alquiler</span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono">{(is2025 ? prop.expensesInsurance : 0).toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-slate-400">{dynamicInsurance.toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-indigo-400 font-bold">{totalInsurance.toLocaleString("es-ES")} €</td>
                            </tr>

                            {/* Community */}
                            <tr className="hover:bg-slate-800/20">
                              <td className="py-2.5 px-3">
                                <span className="block font-medium text-slate-200">Gastos de comunidad y administración</span>
                                <span className="text-[10px] text-slate-500">Cuotas ordinarias, derramas comunitarias, honorarios administración</span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono">{(is2025 ? prop.expensesCommunity : 0).toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-slate-400">{dynamicCommunity.toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-indigo-400 font-bold">{totalCommunity.toLocaleString("es-ES")} €</td>
                            </tr>

                            {/* Amortization */}
                            <tr className="hover:bg-slate-800/20">
                              <td className="py-2.5 px-3">
                                <span className="block font-medium text-slate-200">Amortización de bienes inmuebles (3% s/construcción)</span>
                                <span className="text-[10px] text-slate-500">3% anual deducible sobre el valor de la construcción</span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono">{(is2025 ? prop.amortizationAmount : 0).toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-slate-400">{dynamicAmortization.toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-indigo-400 font-bold">{totalAmortization.toLocaleString("es-ES")} €</td>
                            </tr>

                            {/* Supplies */}
                            <tr className="hover:bg-slate-800/20">
                              <td className="py-2.5 px-3">
                                <span className="block font-medium text-slate-200">Suministros y mantenimiento</span>
                                <span className="text-[10px] text-slate-500">Luz, agua, gas pagados directamente por el propietario</span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono">0 €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-slate-400">{dynamicMaintenance.toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-indigo-400 font-bold">{dynamicMaintenance.toLocaleString("es-ES")} €</td>
                            </tr>

                            {/* Other */}
                            <tr className="hover:bg-slate-800/20">
                              <td className="py-2.5 px-3">
                                <span className="block font-medium text-slate-200">Otros gastos deducibles</span>
                                <span className="text-[10px] text-slate-500">Comisiones de agencia, defensa jurídica, gastos de formalización</span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono">0 €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-slate-400">{dynamicOther.toLocaleString("es-ES")} €</td>
                              <td className="py-2.5 px-3 text-right font-mono text-indigo-400 font-bold">{dynamicOther.toLocaleString("es-ES")} €</td>
                            </tr>

                          </tbody>
                        </table>
                      </div>

                      {/* Dynamic expenses list specifically parsed or scanned for this year */}
                      <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-3.5 space-y-2">
                        <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                          Justificantes y Facturas Individuales de {fiscalFilterYear} ({propertyExpensesForYear.filter(e => e.category !== 'rent').length})
                        </span>
                        {propertyExpensesForYear.filter(e => e.category !== 'rent').length > 0 ? (
                          <div className="space-y-1.5 max-h-[150px] overflow-y-auto">
                            {propertyExpensesForYear.filter(e => e.category !== 'rent').map((exp) => (
                              <div key={exp.id} className="flex justify-between items-center text-[11px] bg-slate-900/60 p-2 rounded-lg border border-slate-800/50">
                                <div className="space-y-0.5">
                                  <span className="text-slate-200 font-medium">{exp.description || "Gasto sin concepto"}</span>
                                  <div className="flex items-center space-x-2 text-[10px] text-slate-500">
                                    <span className="font-mono bg-slate-800/50 px-1 py-0.2 rounded text-[9px] uppercase text-indigo-400 font-bold">
                                      {exp.category}
                                    </span>
                                    <span>•</span>
                                    <span>{new Date(exp.date).toLocaleDateString("es-ES")}</span>
                                  </div>
                                </div>
                                <div className="flex items-center space-x-2">
                                  {deleteExpenseConfirmId === exp.id ? (
                                    <div className="flex items-center gap-1.5 animate-fade-in bg-slate-800 p-1.5 rounded-lg border border-red-500/30">
                                      <span className="text-[10px] text-red-400 font-bold px-1 font-sans">¿Eliminar?</span>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          onDeleteExpense(exp.id);
                                          setDeleteExpenseConfirmId(null);
                                        }}
                                        className="px-2 py-0.5 bg-red-600 hover:bg-red-500 text-white font-bold text-[10px] rounded transition-colors cursor-pointer"
                                      >
                                        Sí
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => setDeleteExpenseConfirmId(null)}
                                        className="px-2 py-0.5 bg-slate-700 hover:bg-slate-600 text-slate-200 text-[10px] rounded transition-colors cursor-pointer"
                                      >
                                        No
                                      </button>
                                    </div>
                                  ) : (
                                    <>
                                      <span className="font-mono text-xs font-bold text-slate-100">-{exp.amount.toLocaleString("es-ES")} €</span>
                                      <button
                                        type="button"
                                        onClick={() => setDeleteExpenseConfirmId(exp.id)}
                                        className="p-1 text-slate-500 hover:text-red-400 hover:bg-red-950/20 rounded-lg transition-colors cursor-pointer"
                                        title="Eliminar Registro"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs text-slate-500 italic">No se han registrado facturas ni recibos específicos por diario para este ejercicio. Se imputarán las estimaciones de la ficha.</p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* BLOC CONTRATO EXPANDIDO */}
                  {openContractPropertyId === prop.id && (
                    <fieldset disabled={cardIsSaving} className="w-full min-w-0 bg-slate-900/80 border border-emerald-500/20 rounded-2xl p-5 mt-4 space-y-5 animate-slide-in text-left">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-800 pb-3 gap-2">
                        <div className="flex items-center space-x-2">
                          <FileText className="w-5 h-5 text-emerald-400" />
                          <div>
                            <h5 className="text-sm font-bold text-white">Contrato de Arrendamiento</h5>
                            <p className="text-[10px] text-slate-400">Detalles de vigencia, cuantía de renta y documento digitalizado del contrato.</p>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {/* Lado izquierdo: Información actual del contrato y subida */}
                        <div className="space-y-4">
                          <h6 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Ficha del Contrato</h6>
                          
                          {prop.contract ? (
                            <div className="bg-slate-950/50 rounded-xl border border-slate-800 p-4 space-y-3.5">
                              <div className="grid grid-cols-2 gap-3 text-xs">
                                <div>
                                  <span className="text-slate-500 block text-[9px] uppercase font-mono">Fecha de Inicio</span>
                                  <span className="font-semibold text-slate-200">
                                    {prop.contract.startDate ? prop.contract.startDate.split("-").reverse().join("/") : "No especificada"}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-slate-500 block text-[9px] uppercase font-mono">Fecha de Fin</span>
                                  <span className="font-semibold text-slate-200">
                                    {prop.contract.endDate ? prop.contract.endDate.split("-").reverse().join("/") : "Indefinido / Prorrogable"}
                                  </span>
                                </div>
                              </div>

                              <div>
                                <span className="text-slate-500 block text-[9px] uppercase font-mono">Cuantía de Alquiler</span>
                                <span className="text-lg font-black text-emerald-400">
                                  {prop.contract.monthlyRent ? prop.contract.monthlyRent.toLocaleString("es-ES") : prop.monthlyRent.toLocaleString("es-ES")} €/mes
                                </span>
                              </div>

                              {prop.contract.pdfName ? (
                                <div className="bg-slate-900 border border-emerald-500/10 rounded-lg p-3 flex items-center justify-between">
                                  <div className="flex items-center space-x-2 min-w-0">
                                    <FileText className="w-5 h-5 text-emerald-400 shrink-0" />
                                    <div className="min-w-0">
                                      <p className="text-xs font-bold text-slate-200 truncate pr-2" title={prop.contract.pdfName}>
                                        {prop.contract.pdfName}
                                      </p>
                                      <p className="text-[10px] text-slate-500 font-mono">{prop.contract.pdfSize || "1.2 MB"}</p>
                                    </div>
                                  </div>
                                  <div className="flex space-x-2 shrink-0">
                                    <a
                                      href="#"
                                      onClick={(e) => {
                                        e.preventDefault();
                                        // El contrato puede estar en el almacenamiento remoto (pdfVaultId),
                                        // en Storage (pdfPath) o no tener archivo (registro anterior/generado).
                                        const contractSource = contractPdfSource(prop.contract ?? {});
                                        if (!hasAttachmentSource(contractSource)) {
                                          alert("Este contrato no tiene archivo guardado (registro anterior o generado sin archivo). Vuelve a adjuntar el PDF.");
                                          return;
                                        }
                                        downloadAttachment({ vaultId: contractSource.vaultId, storagePath: contractSource.storagePath, fileName: prop.contract?.pdfName || "contrato.pdf" })
                                          .catch((err) => alert(err instanceof Error ? err.message : "No se pudo descargar el contrato."));
                                      }}
                                      className="text-[10px] bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 px-2 py-1 rounded font-bold transition-all cursor-pointer"
                                    >
                                      Descargar
                                    </a>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteCardContract(prop)}
                                      className="text-[10px] bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-2 py-1 rounded font-bold transition-all cursor-pointer"
                                    >
                                      Eliminar
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="p-3 bg-amber-950/20 border border-amber-500/10 rounded-lg text-amber-400 text-xs flex items-start space-x-2">
                                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                                  <span>Contrato completado a mano sin documento PDF adjunto. Puedes subir el PDF de respaldo a la derecha.</span>
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="p-5 bg-slate-950/40 border border-dashed border-slate-800 rounded-xl text-center text-slate-500 text-xs space-y-2">
                              <FileText className="w-8 h-8 text-slate-600 mx-auto" />
                              <p className="font-medium">No hay ningún contrato activo registrado para este inmueble.</p>
                              <p className="text-[10px] text-slate-500 max-w-xs mx-auto">Sube el PDF a la derecha o rellena la vigencia para vincular el contrato a este inmueble.</p>
                            </div>
                          )}
                        </div>

                        {/* Lado derecho: Formulario de Modificación / Subida */}
                        <div className="space-y-4 border-t lg:border-t-0 lg:border-l border-slate-800 lg:pl-6 pt-4 lg:pt-0">
                          <h6 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Modificar / Digitalizar Contrato</h6>
                          
                          <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase">Fecha de Inicio</label>
                                <input
                                  type="date"
                                  value={cardStartDate}
                                  onChange={(e) => setCardStartDate(e.target.value)}
                                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-emerald-500"
                                />
                              </div>
                              <div>
                                <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase">Fecha de Fin</label>
                                <input
                                  type="date"
                                  value={cardEndDate}
                                  onChange={(e) => setCardEndDate(e.target.value)}
                                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-emerald-500"
                                />
                              </div>
                            </div>

                            <div>
                              <label className="block text-[10px] text-slate-400 mb-1 font-mono uppercase">Cuantía Alquiler Mensual (€/mes)</label>
                              <input
                                type="text"
                                inputMode="decimal"
                                value={cardMonthlyRent}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (val === "" || /^[0-9]*[.,]?[0-9]*$/.test(val)) {
                                    setCardMonthlyRent(val);
                                  }
                                }}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-emerald-500 font-bold"
                              />
                            </div>

                            {/* Tenant Change Option */}
                            <div className="bg-slate-950/80 border border-amber-500/30 rounded-xl p-3 space-y-2.5">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5 text-amber-300 font-bold text-xs">
                                  <UserPlus className="w-3.5 h-3.5 text-amber-400" />
                                  <span>Registrar Cambio de Inquilino</span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setIsTenantChangeActive(!isTenantChangeActive)}
                                  className={`text-[10px] px-2 py-0.5 rounded-md font-bold font-mono transition-all border cursor-pointer ${
                                    isTenantChangeActive 
                                      ? "bg-amber-500 text-slate-950 border-amber-400" 
                                      : "bg-slate-900 text-amber-400 border-amber-500/30 hover:bg-slate-800"
                                  }`}
                                >
                                  {isTenantChangeActive ? "✓ Activado" : "+ Añadir Nuevo"}
                                </button>
                              </div>

                              <p className="text-[10px] text-slate-400 leading-tight">
                                Al fijar fecha de fin ({cardEndDate || "en contrato"}), añade al nuevo inquilino. Durante el año de transición figurarán ambos inquilinos con sus cuotas correspondientes.
                              </p>

                              {isTenantChangeActive && (
                                <div className="pt-2 border-t border-slate-800 space-y-2.5 animate-fade-in">
                                  <div className="grid grid-cols-2 gap-2">
                                    <div>
                                      <label className="block text-[9px] text-amber-300 font-semibold mb-1">Nuevo Inquilino</label>
                                      <input
                                        type="text"
                                        placeholder="Ej: Laura Gómez"
                                        value={newTenantName}
                                        onChange={(e) => setNewTenantName(e.target.value)}
                                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:ring-1 focus:ring-amber-500"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[9px] text-amber-300 font-semibold mb-1">DNI / NIF</label>
                                      <input
                                        type="text"
                                        placeholder="Ej: 98765432B"
                                        value={newTenantDni}
                                        onChange={(e) => setNewTenantDni(e.target.value)}
                                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:ring-1 focus:ring-amber-500"
                                      />
                                    </div>
                                  </div>

                                  <div className="grid grid-cols-2 gap-2">
                                    <div>
                                      <label className="block text-[9px] text-amber-300 font-semibold mb-1">Fecha Inicio Contrato</label>
                                      <input
                                        type="date"
                                        value={newTenantStartDate}
                                        onChange={(e) => setNewTenantStartDate(e.target.value)}
                                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:ring-1 focus:ring-amber-500"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[9px] text-amber-300 font-semibold mb-1">Renta Nuevo Contrato (€)</label>
                                      <input
                                        type="text"
                                        inputMode="decimal"
                                        placeholder={cardMonthlyRent || "1000"}
                                        value={newTenantMonthlyRent}
                                        onChange={(e) => setNewTenantMonthlyRent(e.target.value)}
                                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white font-bold focus:ring-1 focus:ring-amber-500"
                                      />
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>

                            {/* Drag & Drop simulated uploader */}
                            <div className="space-y-2">
                              <label className="block text-[10px] text-slate-400 font-mono uppercase">Digitalizar / Adjuntar PDF</label>
                              <div className="relative border border-dashed border-slate-800 hover:border-emerald-500/50 rounded-xl p-4 transition-all bg-slate-950/40 text-center">
                                <input
                                  type="file"
                                  accept=".pdf"
                                  onChange={(e) => handleFileChange(e, prop)}
                                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                />
                                {isUploading ? (
                                  <div className="space-y-2">
                                    <Loader2 className="w-5 h-5 text-emerald-400 animate-spin mx-auto" />
                                    <p className="text-[10px] text-slate-300 font-medium">Procesando archivo…</p>
                                  </div>
                                ) : cardPdfName ? (
                                  <div className="space-y-1">
                                    <div className="flex items-center justify-center space-x-1 text-emerald-400">
                                      <CheckCircle className="w-4 h-4" />
                                      <span className="text-[10px] font-bold">¡Archivo seleccionado!</span>
                                    </div>
                                    <p className="text-xs font-semibold text-slate-200 truncate max-w-[200px] mx-auto">{cardPdfName}</p>
                                    <p className="text-[9px] text-slate-500 font-mono">{cardPdfSize || "Fichero PDF"}</p>
                                  </div>
                                ) : (
                                  <div className="space-y-1">
                                    <Upload className="w-5 h-5 text-slate-600 mx-auto" />
                                    <p className="text-[10px] text-slate-400 font-medium">Subir Contrato PDF</p>
                                    <p className="text-[8px] text-slate-500">Arrastra o haz clic para subir</p>
                                  </div>
                                )}
                              </div>
                            </div>

                            {cardError && <p className="text-[10px] text-red-400 mt-2">{cardError}</p>}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3">
                              <button
                                type="button"
                                disabled={cardIsSaving}
                                onClick={async () => {
                                  const ok = await handleSaveCardContract(prop);
                                  if (ok) alert("Contrato registrado en el inmueble. Revisa el estado de guardado en la parte superior.");
                                }}
                                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Guardar Contrato</span>
                              </button>

                              {(prop.contract || (prop.tenantHistory && prop.tenantHistory.length > 0) || prop.tenantName) && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const history = prop.tenantHistory && prop.tenantHistory.length > 0 ? prop.tenantHistory : [];
                                    if (history.length > 0) {
                                      handleDeleteTenantRecord(prop, history[history.length - 1].id, history.length - 1);
                                    } else {
                                      handleDeleteTenantRecord(prop);
                                    }
                                  }}
                                  className="w-full py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>Eliminar Inquilino/Contrato</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </fieldset>
                  )}

                </div>
              );
            })
          ) : (
            <div className="col-span-2 bg-slate-800/10 border border-dashed border-slate-700 rounded-2xl py-16 flex flex-col items-center justify-center text-slate-500 space-y-3">
              <Building className="w-12 h-12 text-slate-600" />
              <p className="text-sm font-medium">No hay ningún inmueble registrado en la cartera.</p>
              <button
                onClick={() => setIsAdding(true)}
                className="text-indigo-400 hover:text-indigo-300 font-bold text-xs underline"
              >
                Añadir tu primer inmueble ahora
              </button>
            </div>
          )}
        </div>
      )}

      {/* EXPORT MODAL */}
      {isExportOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-scale-up">
            <div className="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-800/40">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Exportar Inmuebles</h3>
                  <p className="text-xs text-slate-400">Selecciona el formato de exportación deseado</p>
                </div>
              </div>
              <button
                onClick={() => setIsExportOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <button
                onClick={handleExportJSON}
                className="w-full text-left p-4 rounded-xl border border-slate-700 bg-slate-800/60 hover:bg-slate-800 hover:border-emerald-500/50 text-slate-200 flex items-center gap-3 transition-all cursor-pointer group"
              >
                <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20 shrink-0 group-hover:scale-105 transition-transform">
                  <FileCode className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-sm text-white flex items-center gap-2">
                    Exportar JSON
                    <span className="text-[10px] bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/20">Recomendado</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">Copia exacta de los datos para importar en otra cuenta o perfil de la App.</div>
                </div>
              </button>

              <button
                onClick={handleExportExcel}
                className="w-full text-left p-4 rounded-xl border border-slate-700 bg-slate-800/60 hover:bg-slate-800 hover:border-indigo-500/50 text-slate-200 flex items-center gap-3 transition-all cursor-pointer group"
              >
                <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20 shrink-0 group-hover:scale-105 transition-transform">
                  <FileSpreadsheet className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-sm text-white">Exportar Excel (.xlsx)</div>
                  <div className="text-xs text-slate-400 mt-0.5">Formato de hoja de cálculo ideal para abrir en Microsoft Excel o Google Sheets.</div>
                </div>
              </button>
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-800/40 flex justify-end">
              <button
                type="button"
                onClick={() => setIsExportOpen(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-xl text-xs transition-colors cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* IMPORT MODAL */}
      {isImportOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-scale-up">
            <div className="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-800/40">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Importar Inmuebles</h3>
                  <p className="text-xs text-slate-400">Sube un archivo JSON o hoja de cálculo (.xlsx, .xls, .csv) de inmuebles</p>
                </div>
              </div>
              <button
                onClick={() => setIsImportOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              {/* FILE UPLOADER */}
              <div className="border-2 border-dashed border-slate-700 hover:border-amber-500/50 rounded-2xl p-6 text-center transition-colors bg-slate-950/40">
                <label
                  htmlFor="properties-import-file"
                  className="relative cursor-pointer flex flex-col items-center gap-2"
                >
                  <div className="p-3 bg-slate-800 rounded-xl text-amber-400">
                    <FileSpreadsheet className="w-8 h-8" />
                  </div>
                  <div>
                    <span className="font-semibold text-white text-sm hover:underline">Haz clic para seleccionar archivo</span>
                    <p className="text-xs text-slate-400 mt-1">Soporta archivos JSON, Excel (.xlsx, .xls) y CSV</p>
                    <p className="text-[10px] text-slate-500 mt-1">
                      El formato se valida después de elegir el archivo. En Android, si tu JSON aparece
                      como «archivo», selecciónalo igualmente: no debe quedar en gris.
                    </p>
                  </div>
                  {/* Input cubriendo la zona (sin display:none): con `hidden` y solo
                      extensiones en `accept`, el selector de Android deja los .json en
                      gris o no abre el picker. La validación final es posterior. */}
                  <input
                    type="file"
                    id="properties-import-file"
                    accept={IMPORT_ACCEPT}
                    className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                    onClick={(e) => { e.currentTarget.value = ""; }}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleProcessImportFile(file);
                    }}
                  />
                </label>
              </div>

              {/* ERROR MESSAGE */}
              {importError && (
                <div className="p-3 bg-red-950/40 border border-red-500/30 text-red-300 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{importError}</span>
                </div>
              )}

              {/* SUCCESS MESSAGE */}
              {importSuccessMsg && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{importSuccessMsg}</span>
                </div>
              )}

              {/* STRUCTURE NOTE (copia integral vs. lista aislada) */}
              {importStructureNote && (
                <div className="p-3 bg-slate-800/60 border border-slate-600/50 text-slate-300 rounded-xl text-xs flex items-center gap-2">
                  <FileCode className="w-4 h-4 shrink-0 text-indigo-400" />
                  <span>{importStructureNote}</span>
                </div>
              )}

              {/* REJECTED RECORDS: nunca se descartan en silencio */}
              {importRejected.length > 0 && (
                <div className="p-3 bg-red-950/40 border border-red-500/30 text-red-300 rounded-xl text-xs space-y-1">
                  <div className="flex items-center gap-2 font-semibold">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                    <span>{importRejected.length} registro(s) no importable(s) con seguridad (no se importarán):</span>
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-red-300/80">
                    {importRejected.slice(0, 3).map((r) => (
                      <li key={`${r.index}-${r.key}`}>{r.key}: {r.reason}</li>
                    ))}
                    {importRejected.length > 3 && <li>…y {importRejected.length - 3} más.</li>}
                  </ul>
                </div>
              )}

              {/* WARNINGS: campos no informados; no se inventan datos */}
              {importWarnings.length > 0 && (
                <div className="p-3 bg-amber-950/30 border border-amber-500/30 text-amber-200 rounded-xl text-xs space-y-1">
                  <div className="flex items-center gap-2 font-semibold">
                    <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                    <span>{importWarnings.length} aviso(s) de datos no informados en el archivo (no se inventan importes, fechas, titulares ni relaciones):</span>
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-amber-200/80">
                    {importWarnings.slice(0, 3).map((w) => (
                      <li key={`${w.index}-${w.key}-${w.reason}`}>{w.key}: {w.reason}</li>
                    ))}
                    {importWarnings.length > 3 && <li>…y {importWarnings.length - 3} más.</li>}
                  </ul>
                </div>
              )}

              {/* PREVIEW & MODE CHOICE */}
              {importPreviewData && importPreviewData.length > 0 && (
                <div className="space-y-4 pt-2">
                  <div className="p-3.5 bg-indigo-950/40 border border-indigo-500/30 rounded-xl flex justify-between items-center text-xs">
                    <span className="text-indigo-200 font-medium">Inmuebles detectados en el archivo:</span>
                    <span className="bg-indigo-500/20 text-indigo-300 font-bold px-2.5 py-1 rounded-full border border-indigo-500/30">
                      {importPreviewData.length} inmuebles
                    </span>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-300 block">Modo de Importación:</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setImportMode('merge')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          importMode === 'merge'
                            ? 'bg-amber-500/10 border-amber-500/50 text-amber-300 font-bold'
                            : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:bg-slate-800'
                        }`}
                      >
                        <div className="text-xs">➕ Fusionar (Añadir)</div>
                        <div className="text-[10px] opacity-75 font-normal mt-0.5">Mantiene los inmuebles actuales</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setImportMode('replace')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          importMode === 'replace'
                            ? 'bg-red-500/10 border-red-500/50 text-red-300 font-bold'
                            : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:bg-slate-800'
                        }`}
                      >
                        <div className="text-xs">🔄 Reemplazar todo</div>
                        <div className="text-[10px] opacity-75 font-normal mt-0.5">Sustituye la cartera actual</div>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-800/40 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsImportOpen(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-xl text-xs transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmImport}
                disabled={!importPreviewData || importPreviewData.length === 0 || isImporting}
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-bold rounded-xl text-xs transition-all shadow-lg shadow-amber-500/20"
              >
                Confirmar Importación ({importPreviewData?.length || 0})
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
